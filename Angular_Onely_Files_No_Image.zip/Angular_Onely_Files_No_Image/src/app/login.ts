export class Login {
    public name:string;
    public pssword:string;
}
