import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { first } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
Loginform:FormGroup;
alert_fail:boolean=false;
alert_sucess:boolean=false;
  constructor(public serviceref:UserService,formbulder:FormBuilder, private toaser:ToastrService ,public router:Router) { 
    this.Loginform=formbulder.group({
       name:new FormControl(),
       password:new FormControl(),
    })
  }

  ngOnInit(): void {
  }
  loginMethod(){
   //debugger
   this.serviceref.Loginformcheck(this.Loginform.value).subscribe(x=>{
     console.log(x)
      if(x=="Your Login is Completed Your Going to Home Page"){
        //this.alert_sucess=true;
        this.toaser.success('Your Going to Home Page','Login success!');
        alert('Your Login is Completed Your Going to Home Page')
      this.router.navigate(['uers_list']);
      console.log(x);
    }else{
      this.toaser.error('Password or User Name Wrong','Login Faild!');
      
   //this.alert_fail=true;
   this.Loginform.reset([]);
   console.log(x);
    }
  })
        
      }
      
      }


