import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder, FormControl, Validators} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Action } from 'rxjs/internal/scheduler/Action';
import { UserService } from '../user.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  public Regform:FormGroup;
  x:any;
  submiteddata:boolean=false;
  ///user:{id:string};
  singleuserdsts:any;
  singldata:any;


  constructor(public servicref:UserService, forbulder:FormBuilder,public router:Router,private actrout:ActivatedRoute,private tosastet:ToastrService) {
    this.Regform=forbulder.group({
                  id:new FormControl(""),
                  name:new FormControl("",Validators.required),
                  email:new FormControl("",Validators.required),
                  phone:new FormControl("",Validators.required),
                  password:new FormControl("",Validators.required)
                 
      
    })
   }

  ngOnInit(): void {
  this.CeateReg()
  }
   
  CeateReg(){
    const id=this.actrout.snapshot.params['id'];
    if(id){
      this.servicref.editUsergetdata(id).subscribe(
        (res:any)=>{
          //console.log(res);
  //this.singldata=res;
  //debugger
  this.Regform.patchValue({
   id:res.id,
   name:res.name,
   email:res.email,
   phone:res.phone,
   password:res.password
   
  });
  }); 
  debugger
  if(id){
  this.servicref.updateuser(this.Regform.value,id).subscribe(
    data=>{
  this.router.navigate(['uers_list']);
  this.tosastet.info('Record is Updated Successfully');
  }
  );
}
    }
    else{
    this.submiteddata=true;
    if(this.Regform.invalid){
      return;
    }
    
   debugger
  this.servicref.addUser(this.Regform.value).subscribe(
      x => {
        alert("Your Regstration Completed");
     this.router.navigate(['login']);
     this.Regform.reset();
     this.submiteddata=false;
      console.log(x);
        }
    );
  }

}
}



