import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Users } from './users';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(public httref:HttpClient) { }

 public  addUser(user:Users){ 
   return this.httref.post("http://localhost/web/registration.php", user);
  }
  public Loginformcheck(uesr:Users){
  //debugger
   return this.httref.post("http://localhost/web/login.php", uesr);
      
 }
 public usersList():Observable<Users[]> {
  return this.httref.get<Users[]>("http://localhost/web/user_list.php")
                                 .pipe(catchError(this.ErrorMesseageIs));

 }
 public ErrorMesseageIs(error){
   let errormessage='';
   errormessage = errormessage + 'Error : ' + error.message;
   return throwError(errormessage);

 }

public deleteUser(id:number){
  return this.httref.delete("http://localhost/web/user_list_base_id.php?id=" + id)
                              .pipe(catchError(this.ErrorMesseageIs));

}
public editUsergetdata(id:number):Observable<Users[]>{
  debugger
  return this.httref.get<Users[]>("http://localhost/web/user_list_base_edit_id.php?id=" + id)
                              .pipe(catchError(this.ErrorMesseageIs));

}
public updateuser(uesr:Users,id:number){
  //debugger
  return this.httref.post("http://localhost/web/user_update.php?id=" + id, uesr)
  .pipe(catchError(this.ErrorMesseageIs));
}
 
}


