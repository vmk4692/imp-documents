import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserService } from '../user.service';
import { Users } from '../users';

@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.css']
})
export class UsersListComponent implements OnInit {
userslistdata:any;


  constructor(public serviceref:UserService,public tosastet:ToastrService, public roter:Router) { }

  ngOnInit(): void {
    this.getusers()
  }


getusers(){
this.serviceref.usersList().subscribe(
  (res:any) => {
    console.log(res);
    this.userslistdata=res;
  },
  error=>{
    debugger
   // console.log(error);
    alert(error);
  });
}

delete(id:any){
   if(confirm("Do You Want to delete this user")){

this.serviceref.deleteUser(id).subscribe(
  dt => {
console.log(dt);
this.tosastet.success('Record is Deleted Successfully');
location.reload();
  },
  error=>{
    debugger
   // console.log(error);
    alert(error);
  });
}
}   

// edituser(eid:any){
// //this.roter.navigate(['registration',id]);
// this.serviceref.editUsergetdata(eid).subscribe(
// edituserlist => {
//     debugger
// console.log(edituserlist);
// //this.tosastet.success('Record is get Successfully')
//   },
//   error=>{
//     debugger
//    // console.log(error);
//     alert(error);
//   });
// }
// edituser(id:any){
//   this.roter.navigate(['registration',id]);
// }

}
