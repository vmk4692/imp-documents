<?php 
require 'db.php'; 
?>


<?php 


if(isset($_POST['save'])){
 
  $emp_id=$_POST['emp_id'];
  $emp_name=$_POST['emp_name'];
  $gender=$_POST['gender'];
  $vehicle=$_POST['vehicle'];
  if(isset($_FILES['image'])){

   $errors= array();

      $file_name = $_FILES['image']['name'];

      $file_size =$_FILES['image']['size'];

      $file_tmp =$_FILES['image']['tmp_name'];

      $file_type=$_FILES['image']['type'];

      $explode=(explode('.',$_FILES['image']['name']));
      $file_ext=strtolower(end($explode));

      $extensions= array("jpeg","jpg","png");

      
      if(in_array($file_ext,$extensions)=== false){

         $errors[]="extension not allowed, please choose a JPG or JPEG or PNG file.";

      }

      
      if($file_size > 15097152){

         $errors[]='File size must be exactly 5 MB';

      }

      
      if(empty($errors)==true){

         move_uploaded_file($file_tmp,"images/".$file_name);

         echo "";

      }else{

         print_r($errors); exit;

      }

  }

  $createddate=date('Y-m-d H:i:s');

$query="INSERT INTO employees (emp_id,emp_name,gender,vehicle,image,created_on) VALUES ('$emp_id','$emp_name','$gender',
  '$vehicle','$file_name','$createddate')";
$result=mysqli_query($con,$query);

if($result){
echo'well';
}
else{
  echo'not well';
}

}
 


  







?>




<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style type="text/css">
    body{
      background: #f1f1f1;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="row">
    <div class="col-sm-4 col-sm-offset-4">
  <h2>Vertical (basic) form</h2>
 
     <form class="form-horizontal" role="form" action="add_emp.php" method="post" enctype="multipart/form-data" >
    <div class="form-group">
      <label for="">Employee Id</label>
      <input type="test" class="form-control" placeholder="Enter Id" name="emp_id">
    </div>
    <div class="form-group">
      <label for="">Employee Name</label>
      <input type="test" class="form-control" placeholder="Enter Employee Name" name="emp_name">
    </div>


     <div class="form-group">
      <label for="">Select Gender</label><br>
<input type="radio" name="gender" value="male"> Male<br>
<input type="radio" name="gender" value="female"> Female<br>
<input type="radio" name="gender" value="other"> Other
    </div>
   
    <div class="form-group">
      <label for="">Select vehicle</label><br>

<input type="checkbox" name="vehicle" value="Bike"> I have a bike<br>
<input type="checkbox" name="vehicle" value="Car"> I have a car<br>
<input type="checkbox" name="vehicle" value="Boat" > I have a boat<br>
    </div>

 <div class="form-group">
      <label for="">Upload Image</label>
      <input type="file" class="form-control"  name="image">
    </div> 

    <input type="submit" name="save" value="save"  class="btn btn-success">
  </form>
</div>
</div>

</body>
</html>
