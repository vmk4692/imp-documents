<?php

$dbuser="root";
$dbpass="";
$dbname="company";
$con=new mysqli('localhost',$dbuser,$dbpass,$dbname);



?>