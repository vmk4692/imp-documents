

<?php 
require 'db.php'; 


 $id=$_GET['id'];
 
  $query="DELETE FROM employees WHERE id='$id'";
/* echo '<pre>';
 print_r($query);exit;*/
 $q=mysqli_query($con,$query);

if($q){
header('Location:http://localhost/corephp/list_emp.php');
}
else{
  echo'not well';
}




?>
