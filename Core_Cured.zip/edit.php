<?php 
require 'db.php'; 
?>


<?php 

$eid=$_GET['id'];
//echo $sid;
$query="SELECT * FROM employees WHERE id=$eid;";
$sql=mysqli_query($con,$query);
$re=mysqli_fetch_assoc($sql);
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style type="text/css">
    body{
      background: #f1f1f1;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="row">
    <div class="col-sm-4 col-sm-offset-4">
  <h2>Edit Vertical (basic) form</h2>
 
     <form class="form-horizontal" role="form" action="update.php" method="post" enctype="multipart/form-data" >

              <div class="form-group">
      <input type="hidden" class="form-control" value="<?php echo $re['id']; ?>" name="id">
    </div>



        <div class="form-group">
      <label for="">Employee Id</label>
      <input type="test" class="form-control"  name="emp_id" value="<?php echo $re['emp_id']; ?>">
    </div>


    <div class="form-group">
      <label for="">Employee Name</label>
      <input type="test" class="form-control"  name="emp_name" value="<?php echo $re['emp_name']; ?>">
    </div>


     <div class="form-group">
      <label for="">Select Gender</label><br>

<input type="radio" name="gender" value="male"
 <?php 
if($re['gender']=='male'){
  echo 'checked';
}
?>> Male<br>

<input type="radio" name="gender" value="female"  <?php 
if($re['gender']=='female'){
  echo 'checked';
}
?>> Female<br>
<input type="radio" name="gender" value="other"
 <?php 
if($re['gender']=='other'){
  echo 'checked';
}
?>
> Other
    </div>
   
    <div class="form-group">
      <label for="">Select vehicle</label><br>

<input type="checkbox" name="vehicle" value="Bike" 
<?php 
if($re['vehicle']=='Bike'){
echo 'checked';
}
?>
> I have a bike<br>
<input type="checkbox" name="vehicle" value="Car" 
<?php 
if($re['vehicle']=='Car'){
echo 'checked';
}
?>
> I have a car<br>


<input type="checkbox" name="vehicle" value="Boat"
<?php 
if($re['vehicle']=='Boat'){
echo 'checked';
}
?>
 > I have a boat<br>
    </div> 

   <div class="form-group">
      <label for="">Upload Image</label>
      <input type="file" class=""  name="image" value="">
      <br/>
      <img src="./images/<?php echo $re['image'] ?>"/>
    </div> 

    <input type="submit" name="update" value="update"  class="btn btn-success">
  </form>
</div>
</div>

</body>
</html>
