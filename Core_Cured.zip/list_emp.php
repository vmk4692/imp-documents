
<?php 
session_start();
if(!$_SESSION){
header('Location:http://localhost/corephp/login.php');
}

require 'db.php'; 

$query="SELECT * FROM employees";
$sql=mysqli_query($con,$query);


while ($row=mysqli_fetch_assoc($sql)) {
   $data[]=$row;
}

?>


<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<style type="text/css">
    .custab{
    border: 1px solid #ccc;
    padding: 5px;
    box-shadow: 3px 3px 2px #ccc;
    transition: 0.5s;
    }
.custab:hover{
    box-shadow: 3px 3px 0px transparent;
    transition: 0.5s;
    }
</style>
<div class="container">
  <a href="logout.php">logout</a>
    <div class="row col-md-10 col-md-offset-1 custyle">
    <table class="table table-striped custab">
    <thead>
    <a href="#" class="btn btn-primary btn-xs pull-right"><b>+</b> Add new categories</a>
        <tr>
          <th>S.no</th>
            <th>EMP ID</th>
            <th>EMP NAME</th>
            <th>Gender</th>
            <th>Vehicles</th>
            <th>Image</th>
            <th>Status</th>
            <th class="text-center">Action</th>
        </tr>
    </thead>
    <?php 
    $i=1;
    foreach ($data as $list) {?>
      
            <tr>
              <td><?php echo $i++; ?></td>
                <td><?php echo $list['emp_id']; ?></td>
                 <td><?php echo $list['emp_name']; ?></td>
                  <td><?php echo $list['gender']; ?></td>
                   <td><?php echo $list['vehicle']; ?></td>
                   <td><img src="./images/<?php echo $list['image']; ?>" width=100px; /></td>
                   
                   <td><?php 
                   if($list['status']=='Active'){?>
                   
                   <a class='btn btn-primary btn-xs' href="<?php echo"statuschang.php?id=$list[id]&status=$list[status]" ?>"> Active</a>


                   <?php }
                   elseif($list['status']=='Inactive'){?>

                    <a class='btn btn-danger btn-xs' href="<?php echo"statuschang.php?id=$list[id]&status=$list[status]" ?>">In Active</a>

                   <?php }
                   ?>
                       
                   </td>
             
                <td class="text-center"><a class='btn btn-info btn-xs' href="<?php echo"edit.php?id=$list[id];"?>"><span class="glyphicon glyphicon-edit"></span> Edit</a> 
                    <a href="<?php echo"delete.php?id=$list[id];"?>" class="btn btn-danger btn-xs"><span class="glyphicon glyphicon-remove"></span> Del</a></td>
            </tr>
             <?php }
            ?>
    </table>
    </div>
</div>

