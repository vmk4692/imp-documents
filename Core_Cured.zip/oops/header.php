<?php

class my1{

	private $name='Murali';
	public function deat(){
		$re=$this->name;
		return $re;
	}
}

class myp{

	public function deatp(){
		$re=$this->name;
		return $re;
	}
}
?>