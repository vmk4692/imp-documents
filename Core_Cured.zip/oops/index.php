<?php include 'header.php';?>
<html>
<head>
</head>
<body>
	<?php
	$n=new my1();
	echo $n->name;

	?>
	<h4></h4>
</body>
</html>