<?php

session_start();
/*if(!$_SESSION){
header('Location:http://localhost/corephp/login.php');
}*/


 $frist_time= time();
echo '<pre>';print_r($frist_time);

  if (($frist_time + 1 * 60) < time()) {
     header('Location:http://localhost/corephp/login.php');

  } else {

  	echo '<pre>';print_r($frist_time + 1 * 60);

     echo ' session ok';
  }


?>