<?php include 'db.php'; ?>


<?php
$sid=$_GET['id'];
$stu=$_GET['status'];

//echo $sid;
//echo $stu;



if($stu=='Active'){
 $st='Inactive';
}
elseif($stu=='Inactive'){
$st='Active';
}



$query="UPDATE employees SET status='$st' WHERE id=$sid";
 //echo '<pre>'; print_r($query); exit;
$sql=mysqli_query($con,$query);
if($sql){
	header('Location:http://localhost/corephp/list_emp.php');
}

?>