<?php
$x = 10;  
$y = 3;

$re= $x % $y;
echo $re;

?>  