

<?php 
require 'db.php'; 

if(isset($_POST['update'])){
 $id=$_POST['id'];
  $emp_id=$_POST['emp_id'];
  $emp_name=$_POST['emp_name'];
  $gender=$_POST['gender'];
  $vehicle=$_POST['vehicle'];

  $eid=$_POST['id'];
//echo $sid;
$query="SELECT * FROM employees WHERE id=$eid;";
$sql=mysqli_query($con,$query);
$re=mysqli_fetch_assoc($sql);


  if(isset($_FILES['image'])){

      $errors= array();

      $file_name = $_FILES['image']['name'];

      $file_size =$_FILES['image']['size'];

      $file_tmp =$_FILES['image']['tmp_name'];

      $file_type=$_FILES['image']['type'];

      $explode=(explode('.',$_FILES['image']['name']));
      $file_ext=strtolower(end($explode));

      $extensions= array("jpeg","jpg","png");

      
      if(in_array($file_ext,$extensions)=== false){

         $errors[]="extension not allowed, please choose a JPG or JPEG or PNG file.";

      }

      
      if($file_size > 15097152){

         $errors[]='File size must be exactly 5 MB';

      }

      
      if(empty($errors)==true){
      	$file_with_path='images/'.$re['image'];
      	//echo $file_with_path; exit;
      	if (file_exists($file_with_path)) {
        unlink($file_with_path);
        }
  
         move_uploaded_file($file_tmp,"images/".$file_name);

         echo "";


      }else{
        
         print_r($errors); exit;

      }

  }

  $query="UPDATE employees SET  emp_id='$emp_id', emp_name='$emp_name',gender='$gender',vehicle='$vehicle',image ='$file_name' WHERE id=$id";
/* echo '<pre>';
 print_r($query);exit;*/
 $q=mysqli_query($con,$query);

if($q){
header('Location:http://localhost/corephp/list_emp.php');
}
else{
  echo'not well';
}


}

?>
