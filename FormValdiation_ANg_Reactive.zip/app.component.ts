import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup, Validators } from '@angular/forms';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { Customvalidator,MustMatch } from './customvalidator';
//import { MustMatch } from './_helpers/must-match.validator';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'test';
   public formReg:FormGroup;

  constructor(private fbd:FormBuilder){ }
 
  ngOnInit(): void {
    this.formReg=this.fbd.group({
      useName:["",[Validators.required,Validators.minLength(4)]],
      mobile:["",[Validators.required,Validators.minLength(10),Validators.maxLength(10),Customvalidator.numeric]],
      email:["",[Validators.required,Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
      
    },{
      validator: MustMatch('password', 'confirmPassword')
    });
   
  }
    // convenience getter for easy access to form fields
    //get f() { return this.formReg.controls; }
  get useName(){return this.formReg.get('useName');}
  get mobile(){return this.formReg.get('mobile');}
  get email(){return this.formReg.get('email');}
  get password(){return this.formReg.get('password');}
  get confirmPassword(){return this.formReg.get('confirmPassword');}

  getFrom(){
    if(this.formReg.valid){
    console.log(this.formReg.value);
  }
}
    
  
}
