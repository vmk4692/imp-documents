-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 03, 2020 at 12:23 AM
-- Server version: 5.6.46-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chairmansirweb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_about`
--

CREATE TABLE `tbl_about` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `image` varchar(220) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `delete_status` enum('1','0') NOT NULL DEFAULT '1' COMMENT '1=>available,0=>deleted',
  `created_on` datetime NOT NULL,
  `modified_on` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_about`
--

INSERT INTO `tbl_about` (`id`, `title`, `content`, `image`, `status`, `delete_status`, `created_on`, `modified_on`) VALUES
(7, 'murali', 'jhkj', 'assets/images/about/11.gif', 'Inactive', '0', '0000-00-00 00:00:00', '2019-10-31 18:20:49'),
(10, '147', 'y', 'assets/images/about/1.jpg', 'Active', '0', '2019-10-31 18:14:36', '2019-10-31 18:14:41'),
(11, 'About Yeluri Sambasiva Rao', 'Yeluri Sambasiva Rao,MLA, From the Parchur Assembly Consistuency of Prakasam dist, in Andhra Pradesh is a young and dynamic leader in this new generation. He was born at konanki Village in Martur Mandal (Prakasam Dist.). He completed his primary education at his native place and upper primary education at Govt residential school of Chilakaluripet, Guntur dist.\r\n\r\nInitially his ambition was to become a doctor but due to his affection and interest in the farming community, he opted to study horticulture and completed his post-graduation from the prestigious Acharya NG Ranga Agricultural University at Hyderabad.\r\n\r\nSince his childhood he was a diehard fan of late Dr. Nandamuri Taraka Rama Rao, also known as the great legend of the Telugu speaking community and the founder of the TELUGU DESAM PARTY.\r\n\r\nOne of his slogan “SAMAJAME DEVALAYAM – PRAJALE DEVULU” attracted Sambasiva Rao the most. NTR’s image and his personality drew the attention of crores of Telugu youth to work for Telugu Desam party, and Mr. Sambasiva Rao was one of them\r\n\r\nMr. Samba Siva Rao lead his university mates to work on the principles of TDP & worked for social reforms, women empowerment & to address the downtrodden problems even during his days of education.', 'assets/images/about/aboutpageimg1.png', 'Active', '1', '2019-10-31 18:20:40', '2019-11-01 16:36:29');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_achievements_content`
--

CREATE TABLE `tbl_achievements_content` (
  `id` int(11) NOT NULL,
  `image` varchar(220) NOT NULL,
  `status` enum('Active','Deactive') NOT NULL DEFAULT 'Active',
  `delete_status` enum('1','0') NOT NULL DEFAULT '1' COMMENT '1=>available,0=>unavailable',
  `created_on` datetime NOT NULL,
  `modified_on` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_achievements_content`
--

INSERT INTO `tbl_achievements_content` (`id`, `image`, `status`, `delete_status`, `created_on`, `modified_on`) VALUES
(30, 'assets/images/achievements/365.png', 'Active', '1', '2019-11-06 17:12:28', '2019-11-07 17:16:18');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_achievements_content_details`
--

CREATE TABLE `tbl_achievements_content_details` (
  `id` int(11) NOT NULL,
  `content_id` int(11) NOT NULL,
  `title` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_achievements_content_details`
--

INSERT INTO `tbl_achievements_content_details` (`id`, `content_id`, `title`) VALUES
(84, 30, '6'),
(83, 30, '5'),
(82, 30, '4'),
(81, 30, '3');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admins`
--

CREATE TABLE `tbl_admins` (
  `id` int(11) NOT NULL,
  `user` varchar(220) NOT NULL,
  `password` varchar(220) NOT NULL,
  `email` varchar(220) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `lastlogin_date` datetime NOT NULL,
  `created_on` datetime NOT NULL,
  `modified_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admins`
--

INSERT INTO `tbl_admins` (`id`, `user`, `password`, `email`, `status`, `lastlogin_date`, `created_on`, `modified_on`) VALUES
(1, 'admin', 'e10adc3949ba59abbe56e057f20f883e', 'vmk4692@gmail.com', 'Active', '2019-12-04 14:39:35', '2019-10-14 00:00:00', '2019-10-14 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_loginhistory`
--

CREATE TABLE `tbl_admin_loginhistory` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `login_date` date NOT NULL,
  `login_time` time DEFAULT NULL,
  `logout_date` date NOT NULL,
  `logout_time` time DEFAULT NULL,
  `ip_address` varchar(225) NOT NULL,
  `browser_name` varchar(225) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin_loginhistory`
--

INSERT INTO `tbl_admin_loginhistory` (`id`, `admin_id`, `login_date`, `login_time`, `logout_date`, `logout_time`, `ip_address`, `browser_name`, `status`, `created_on`) VALUES
(1, 1, '2019-12-04', '14:39:35', '0000-00-00', NULL, '183.82.115.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36', '1', '2019-12-04 14:39:35');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_email_history_online`
--

CREATE TABLE `tbl_email_history_online` (
  `id` int(11) NOT NULL,
  `event` varchar(225) NOT NULL,
  `name` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `subject` text NOT NULL,
  `email_message` text NOT NULL,
  `sent_date_time` datetime NOT NULL,
  `ip_address` varchar(225) NOT NULL,
  `browser_name` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_email_templates`
--

CREATE TABLE `tbl_email_templates` (
  `id` int(11) NOT NULL,
  `user_type` varchar(225) NOT NULL,
  `page_name` varchar(225) NOT NULL,
  `event` text NOT NULL,
  `subject` text NOT NULL,
  `content` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_email_templates`
--

INSERT INTO `tbl_email_templates` (`id`, `user_type`, `page_name`, `event`, `subject`, `content`) VALUES
(1, 'admin', 'Admin forgot Password', 'Admin Forgot Password', 'Dear Admin - Your Password has been Reset Successfully.', '<tr>\r\n    <td height=\"1\" align=\"left\" valign=\"top\" bgcolor=\"#dcdcdc\"></td>\r\n  </tr>\r\n  <tr>\r\n    <td align=\"left\" valign=\"top\">&nbsp;</td>\r\n  </tr>\r\n  <tr>\r\n    <td align=\"left\" valign=\"top\"><table width=\"680\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">\r\n      <tbody>\r\n	  <tr>\r\n        <td align=\"left\" valign=\"top\"><span style=\"fontsize:12px;font-weight:bold;\">Dear {NAME},</span><br><br>\r\n          <span style=\"margin-left:50px;\"> Your Password Reset Successfully.</span></td>\r\n      </tr>\r\n	  <tr>\r\n	<td>\r\n	<table width=\"600\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">\r\n		\r\n		\r\n		\r\n		\r\n		\r\n		<tr>\r\n			<td style=\"padding:5px\" width=\"16%\">\r\n				<span style=\"color:#333;font-weight:bold;\" >User Name</span>\r\n			</td> \r\n			<td style=\"padding:5px\" width=\"3%\">\r\n			<span  style=\"color:#333;font-weight:bold;\"> :</span> \r\n			</td>\r\n			<td style=\"padding:5px\" width=\"76%\">\r\n			<span  style=\" \">{USERNAME}</span> \r\n			</td>\r\n			\r\n		</tr>\r\n		<tr>\r\n			<td style=\"padding:5px\" width=\"16%\">\r\n				<span style=\"color:#333;font-weight:bold;\" >Password</span>\r\n			</td> \r\n			<td style=\"padding:5px\" width=\"3%\">\r\n			<span  style=\"color:#333;font-weight:bold;\"> :</span> \r\n			</td>\r\n			<td style=\"padding:5px\" width=\"76%\">\r\n			<span  style=\" \">{PASSWORD}</span> \r\n			</td>\r\n			\r\n		</tr>\r\n		\r\n		</table>   \r\n	</td>\r\n		</tr>\r\n	</tbody>\r\n	</table>   \r\n	</td>\r\n  </tr>\r\n  <tr>\r\n    <td align=\"left\" valign=\"top\">&nbsp;</td>\r\n  </tr>'),
(2, 'admin', 'header', 'header', 'header', '<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\r\n<!-- saved from url=(0063)https://www.bestbus.in/bestadmin/sent-email-message.php?id=4531 -->\r\n<html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\r\n\r\n<script type=\"text/javascript\">var NREUMQ=NREUMQ||[];NREUMQ.push([\"mark\",\"firstbyte\",new Date().getTime()]);</script><title>Email Template</title>\r\n<style type=\"text/css\"></style></head>\r\n<body style=\"margin: 0px; padding: 0px; font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: rgb(0, 0, 0); font-weight: normal; text-decoration: none; line-height: 17px; background-color: rgb(255, 255, 255);\">\r\n\r\n<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\r\n  <tbody><tr>\r\n    <td>\r\n\r\n\r\n\r\n<table width=\"700\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\" style=\"border:#cccccc solid 2px; -moz-border-radius:6px; -webkit-border-radius:6px; border-radius:6px; padding:2px;\">\r\n  <tbody><tr>\r\n   <td align=\"left\" valign=\"top\"><table width=\"680\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">\r\n      <tbody><tr>\r\n        <td width=\"271\" align=\"left\" valign=\"middle\"><a href=\"{WEBSITE}\"><img src=\"{WEBSITE}{FOLDER}/{LOGO}\" width=\"187\" height=\"56\" border=\"0\"></a></td>\r\n        <td width=\"269\" align=\"right\" valign=\"middle\"><table width=\"43%\" border=\"0\" align=\"right\" cellpadding=\"0\" cellspacing=\"0\">\r\n          <tbody><tr> \r\n            <td width=\"14%\" height=\"25\" align=\"left\" valign=\"middle\"><img src=\"{WEBSITE}assets/admin/images/mail_icons/phone.jpg\" width=\"13\" height=\"15\"></td>\r\n            <td width=\"86%\" height=\"25\" align=\"left\" valign=\"middle\" style=\"font-size:12px; font-weight:bold;\">{PHONE}</td>\r\n          </tr>\r\n          <tr>\r\n            <td width=\"19%\" height=\"25\" align=\"left\" valign=\"middle\"><img src=\"{WEBSITE}assets/admin/images/mail_icons/mail.jpg\" width=\"16\" height=\"15\"></td>\r\n            <td height=\"25\" align=\"left\" valign=\"middle\" style=\"color:#000; text-decoration:none; font-size:12px; font-weight:bold;\"><a href=\"mailto:http://www.yelurisambasivarao.com\" style=\"color:#c71e1e; text-decoration:none; font-size:12px; font-weight:bold;\">{EMAIL}</a></td>\r\n          </tr>\r\n        </tbody></table></td>\r\n      </tr>\r\n    </tbody></table></td>\r\n  </tr>'),
(3, 'admin', 'footer', 'footer', 'footer', '<tr>\r\n    <td align=\"left\" valign=\"top\" style=\"background-color:#f9f9f9; border-top:#cccccc solid 1px; padding:5px;\"><table width=\"680\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">\r\n      <tbody><tr>\r\n        <td width=\"240\" align=\"left\" valign=\"top\" style=\"font-size:12px; font-weight:bold;\">\r\n            Thanks &amp; Regards<br>\r\n            Yelurisambasivarao Team.<br>\r\n            <a href=\"{WEBSITE}\" style=\" color:#c71e1e; text-decoration:none; font-size:12px; font-weight:bold;\" target=\"_blank\">www.yelurisambasivarao.com</a>\r\n        </td>\r\n        <td width=\"431\" align=\"right\" valign=\"middle\"><table width=\"25%\" border=\"0\" align=\"right\" cellpadding=\"0\" cellspacing=\"0\">\r\n          <tbody><tr>\r\n            <td align=\"left\" valign=\"middle\" colspan=\"6\" style=\"font-weight:bold\">Follow Us On:</td>\r\n          </tr>\r\n           <tr>\r\n				<td align=\"center\" valign=\"middle\"><a href=\"{FACEBOOK}\" target=\"_blank\"><img src=\"{WEBSITE}assets/admin/images/mail_icons/facebook.png\" width=\"17px\" height=\"17px\" style=\"margin-right:3px\" >  </a></td>\r\n				<td align=\"center\" valign=\"middle\"><a href=\"{TWITTER}\" target=\"_blank\"><img src=\"{WEBSITE}assets/admin/images/mail_icons/twitter.png\" width=\"17px\" height=\"17px\" style=\"margin-right:3px\"> </a></td>\r\n				<td align=\"center\" valign=\"middle\"><a href=\"{GOOGLEPLUS}\" target=\"_blank\"><img src=\"{WEBSITE}assets/admin/images/mail_icons/gplus.png\" width=\"17px\" height=\"17px\" style=\"margin-right:3px\"></a></td>\r\n				<td align=\"center\" valign=\"middle\"><a href=\"{YOUTUBE}\" target=\"_blank\"><img src=\"{WEBSITE}assets/admin/images/mail_icons/youtube.png\" width=\"17px\" height=\"17px\" style=\"margin-right:3px\"> </a></td>\r\n          </tr>\r\n        </tbody></table></td>\r\n      </tr>\r\n    </tbody></table></td>\r\n  </tr>\r\n</tbody></table>\r\n\r\n\r\n    </td>\r\n  </tr>'),
(5, 'admin', 'Admin Password verification link', 'Admin password verification link', 'Admin password verification link', '<tr>\r\n    <td height=\"1\" align=\"left\" valign=\"top\" bgcolor=\"#dcdcdc\"></td>\r\n  </tr>\r\n  <tr>\r\n    <td align=\"left\" valign=\"top\">&nbsp;</td>\r\n  </tr>\r\n  <tr>\r\n    <td align=\"left\" valign=\"top\"><table width=\"680\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">\r\n      <tbody>\r\n	  <tr>\r\n        <td align=\"left\" valign=\"top\"><span style=\"fontsize:12px;font-weight:bold;\">Dear {NAME},</span><br><br>\r\n          <span style=\"margin-left:50px;\"> This is Email verification link for Update your Password Please Link on bellow link.</span></td>\r\n      </tr>\r\n	  <tr>\r\n	<td>\r\n	<table width=\"600\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\">\r\n		\r\n		<tr>\r\n		  <td class=\"form-group\">\r\n                               \r\n               <a href=\"{URL}\">\r\n               <button type=\"submit\" name=\"submit\" class=\"btn btn-info btn-md\" value=\"LINK\">Click here</button>\r\n               </a>\r\n              </td>\r\n             </tr>\r\n		\r\n		\r\n	</table>   \r\n	</td>\r\n		</tr>\r\n	</tbody>\r\n	</table>   \r\n	</td>\r\n  </tr>\r\n  <tr>\r\n    <td align=\"left\" valign=\"top\">&nbsp;</td>\r\n  </tr>');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_profiledetials`
--

CREATE TABLE `tbl_profiledetials` (
  `id` int(11) NOT NULL,
  `filed_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `place_order` int(11) NOT NULL,
  `status` enum('Active','Deactive') NOT NULL DEFAULT 'Active',
  `delete_status` enum('1','0') NOT NULL DEFAULT '1' COMMENT '1=>available,0=>unavailable',
  `created_on` datetime NOT NULL,
  `modified_on` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_profiledetials`
--

INSERT INTO `tbl_profiledetials` (`id`, `filed_id`, `description`, `place_order`, `status`, `delete_status`, `created_on`, `modified_on`) VALUES
(12, 13, 'muralikrishna', 1, 'Active', '1', '2019-11-04 13:27:44', '0000-00-00 00:00:00'),
(13, 14, '11-12-1991 ', 2, 'Active', '1', '2019-11-04 15:56:59', '2019-11-04 16:35:53');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_profilefileds`
--

CREATE TABLE `tbl_profilefileds` (
  `id` int(11) NOT NULL,
  `filedname` varchar(220) NOT NULL,
  `status` enum('Active','Deactive') NOT NULL DEFAULT 'Active',
  `delete_status` enum('1','0') NOT NULL DEFAULT '1' COMMENT '1=>available, 0=>unavailable',
  `created_on` datetime DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_profilefileds`
--

INSERT INTO `tbl_profilefileds` (`id`, `filedname`, `status`, `delete_status`, `created_on`, `modified_on`) VALUES
(14, 'dob', 'Active', '1', '2019-11-04 13:00:14', NULL),
(13, 'Name', 'Active', '1', '2019-11-04 12:59:09', '2019-11-04 13:02:48');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_social_links`
--

CREATE TABLE `tbl_social_links` (
  `id` int(11) NOT NULL,
  `facebook_link` text NOT NULL,
  `twitter_link` text NOT NULL,
  `youtube_link` text NOT NULL,
  `instagram_link` text NOT NULL,
  `web_email` varchar(220) NOT NULL,
  `created_on` datetime NOT NULL,
  `modified_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_social_links`
--

INSERT INTO `tbl_social_links` (`id`, `facebook_link`, `twitter_link`, `youtube_link`, `instagram_link`, `web_email`, `created_on`, `modified_on`) VALUES
(1, 'https://www.facebook.com/MLAParchur/', 'https://twitter.com/MLAParchur?ref_src=twsrc%5Etfw%7Ctwcamp%5Eembeddedtimeline%7Ctwterm%5Eprofile%3AMLAParchur&ref_url=http%3A%2F%2Fwww.yelurisambasivarao.com%2Fdemo%2Findex.php', 'https://www.youtube.com/channel/UCXA14o0KtjNAHHe_LKvS4uw', 'yeluri.tdp@gmail.com', 'yeluri.tdp@gmail.com', '0000-00-00 00:00:00', '2019-10-29 12:06:50');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vision`
--

CREATE TABLE `tbl_vision` (
  `id` int(11) NOT NULL,
  `description` text NOT NULL,
  `status` enum('Active','Deactive') NOT NULL DEFAULT 'Active',
  `delete_status` enum('1','0') NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL,
  `modified_on` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_vision`
--

INSERT INTO `tbl_vision` (`id`, `description`, `status`, `delete_status`, `created_on`, `modified_on`) VALUES
(1, 'test', 'Active', '1', '2019-11-11 00:00:00', '2019-11-11 00:00:00'),
(2, 'fgfhg', 'Active', '1', '2019-11-18 13:07:00', '0000-00-00 00:00:00'),
(3, 'xcvxcvcxv', 'Active', '1', '2019-11-18 13:07:17', '0000-00-00 00:00:00'),
(4, 't', 'Active', '1', '2019-11-18 13:16:27', '0000-00-00 00:00:00'),
(5, 'v', 'Active', '1', '2019-11-18 13:17:54', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_web_settings`
--

CREATE TABLE `tbl_web_settings` (
  `id` int(11) NOT NULL,
  `host_name` varchar(225) COLLATE utf8_unicode_ci NOT NULL,
  `logo` varchar(225) COLLATE utf8_unicode_ci NOT NULL,
  `logo_alt_tag` varchar(225) COLLATE utf8_unicode_ci NOT NULL,
  `favicon` varchar(225) COLLATE utf8_unicode_ci NOT NULL,
  `mail_template_admin_email` varchar(225) COLLATE utf8_unicode_ci NOT NULL,
  `mail_template_admin_mobile` varchar(225) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_web_settings`
--

INSERT INTO `tbl_web_settings` (`id`, `host_name`, `logo`, `logo_alt_tag`, `favicon`, `mail_template_admin_email`, `mail_template_admin_mobile`) VALUES
(1, 'http://www.raithubharatam.com', 'MJB.png', 'http://www.raithubharatam.com', 'favicon.png', 'test@gmail.com', '123456789');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_about`
--
ALTER TABLE `tbl_about`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_achievements_content`
--
ALTER TABLE `tbl_achievements_content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_achievements_content_details`
--
ALTER TABLE `tbl_achievements_content_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admins`
--
ALTER TABLE `tbl_admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin_loginhistory`
--
ALTER TABLE `tbl_admin_loginhistory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_email_history_online`
--
ALTER TABLE `tbl_email_history_online`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_email_templates`
--
ALTER TABLE `tbl_email_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_profiledetials`
--
ALTER TABLE `tbl_profiledetials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_profilefileds`
--
ALTER TABLE `tbl_profilefileds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_social_links`
--
ALTER TABLE `tbl_social_links`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_vision`
--
ALTER TABLE `tbl_vision`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_web_settings`
--
ALTER TABLE `tbl_web_settings`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_about`
--
ALTER TABLE `tbl_about`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_achievements_content`
--
ALTER TABLE `tbl_achievements_content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `tbl_achievements_content_details`
--
ALTER TABLE `tbl_achievements_content_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `tbl_admins`
--
ALTER TABLE `tbl_admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_admin_loginhistory`
--
ALTER TABLE `tbl_admin_loginhistory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_email_history_online`
--
ALTER TABLE `tbl_email_history_online`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `tbl_email_templates`
--
ALTER TABLE `tbl_email_templates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_profiledetials`
--
ALTER TABLE `tbl_profiledetials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_profilefileds`
--
ALTER TABLE `tbl_profilefileds`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_social_links`
--
ALTER TABLE `tbl_social_links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_vision`
--
ALTER TABLE `tbl_vision`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_web_settings`
--
ALTER TABLE `tbl_web_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
