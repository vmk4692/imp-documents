<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller

{
  public $data=array();
  function __construct()

  {

    parent::__construct();  
  //echo '123';exit;

      $this->load->model('Adminmodel','mymodel');
      $this->load->model('Common_model','common_model');
      $this->is_logged_in();
      $this->data['msg']='';


   } 

   


  public function is_logged_in()
	{
		$admin_id= $this->session->userdata('admin_id');		
		if(!isset($admin_id) || $admin_id != true)
		{
			redirect('admin_login', 'refresh');
		}
	}
  
    public function list_sociallinks(){
      //echo 'hop'; exit;
      $this->data['sdata']=$this->mymodel->list_sociallinks_m();


      $this->load->view('admin/includes/header');
      $this->data['message']=$this->load->view('admin/includes/message',$this->data,TRUE);
      $this->load->view('admin/list_sociallinks',$this->data);
      $this->load->view('admin/includes/footer');
    }

    public function edit_sociallinks($id){
      //echo $id; exit;

      $this->data['edata']=$this->mymodel->edit_sociallinks_m($id);
     
      $this->load->view('admin/includes/header');
      $this->load->view('admin/edit_sociallinks',$this->data);
      $this->load->view('admin/includes/footer');

    }
    public function update_sociallinks(){
   if($this->input->post('submit') !=''){

    //echo '<pre>';print_r($this->input->post());exit;
    $results=$this->mymodel->update_sociallinks_m($this->input->post());
    if($results){
    $this->session->set_flashdata('success', 'Data is Updated successfully');
    redirect(base_url('admin/list_sociallinks'));
    }
    else{
      redirect(base_url('admin/edit_sociallinks/'.$id));
    }
   }
    }
    
    public function add_about(){
    	      
  if($this->input->post('submit') !=''){

if($_FILES['image']['name'] !=''){
$config['upload_path']          = './assets/images/about';
$config['allowed_types']        = 'pdf|jpg|png|gif';
$config['max_size']             = 2000;
$this->load->library('upload', $config);
if(! $this->upload->do_upload('image'))
{
  $data['msg'] = $this->upload->display_errors();
  $this->session->set_flashdata('error', $data['msg']);
  redirect(base_url().'admin/add_about/'.$id);

}else{

$imgdata = $this->upload->data();
$image = 'assets/images/about/'.$imgdata['file_name'];

}
}

        $title=$this->input->post('title');
        $content=$this->input->post('content');

              $insert=array(
                'title'=>$title,
                'content'=>$content,
                'image'=>$image,
                'created_on'=>date('Y-m-d H:i:s')
            );

          $results=$this->mymodel->add_about_m($insert);
          if($results==1){
          	$this->session->set_flashdata('success', 'Data is Submited successfully');
          	redirect(base_url('admin/list_about'));
          }
  }
      //$this->data['msg']='';
        $this->load->view('admin/includes/header');
        $this->data['message']=$this->load->view('admin/includes/message',$this->data,TRUE);
    	$this->load->view('admin/add_about',$this->data);
    	$this->load->view('admin/includes/footer');
    }


   




    public function list_about(){
    	$this->data['aboutdata']=$this->mymodel->list_about_m();

      $this->load->view('admin/includes/header');
      $this->data['message']=$this->load->view('admin/includes/message',$this->data,TRUE);
      $this->load->view('admin/list_about',$this->data);
      $this->load->view('admin/includes/footer');
    }

    public function update_status($id,$status){
    	$results=$this->mymodel->update_status_m($id,$status);
    	if($results==1){
    		$this->session->set_flashdata('success', 'Status is Changed successfully');
          	redirect(base_url('admin/list_about'));
    	}


    }


    public function edit_about($id){
    	$this->data['showdata']=$this->mymodel->edit_about_m($id);

    	$this->load->view('admin/includes/header');
       $this->data['message']=$this->load->view('admin/includes/message',$this->data,TRUE);
    	$this->load->view('admin/edit_about',$this->data);
    	$this->load->view('admin/includes/footer');
    }


      public function update_about(){

        if($this->input->post('update')!=''){
            $id=$this->input->post('id');
        $rowdata=$this->mymodel->edit_about_m($id);

      // echo '<pre>';print_r($_FILES);exit;

        if($_FILES['image']['name'] !=''){

		$config['upload_path']          = './assets/images/about';
		$config['allowed_types']        = 'pdf|jpg|png|gif';
		//$config['max_size']             = 2000;
		$this->load->library('upload', $config);

			if(! $this->upload->do_upload('image'))
			{
					$data['msg'] = $this->upload->display_errors();
					$this->session->set_flashdata('error', $data['msg']);
					redirect(base_url().'admin/edit_about/'.$id);

			}else{
			
			$imgdata = $this->upload->data();
			$image = 'assets/images/about/'.$imgdata['file_name'];

			$file = './'.$rowdata['image'];
			if(is_file($file));
			unlink($file);

			}
		}else{
			$image = $rowdata['image'];
		}
        
         $results=$this->mymodel->update_about_m($this->input->post(),$image);
         if($results==1){
         	$this->session->set_flashdata('success', 'Data is Updated successfully');
          	redirect(base_url('admin/list_about'));
         }
         else{
         	$this->session->set_flashdata('error', 'Data is  Not Updated');
         }

      	}
      	

      	}
     


     
      public function delete_status($id,$delete_status){
     	$results=$this->mymodel->delete_status_m($id,$delete_status);
     	if($results==1){
     		$this->session->set_flashdata('success', 'Data is Delete successfully');
          	redirect(base_url('admin/list_about'));
     	}

     }



     public function list_profilefileds(){
      
      $this->data['profilefiledsdata']=$this->mymodel->list_profilefileds_m();
    
      $this->load->view('admin/includes/header');
      $this->data['message']=$this->load->view('admin/includes/message',$this->data,TRUE);
      $this->load->view('admin/list_profilefileds',$this->data);
      $this->load->view('admin/includes/footer');

     }

     public function add_profilefileds(){

        $filedname=$this->input->post('filedname');

  
    $aftercheck=$this->mymodel->add_check_profilefileds_m($filedname);
     if($aftercheck){
      $this->session->set_flashdata('error', 'This this Name already exists');
            redirect(base_url('admin/add_profilefileds'));
     }
     else{
      if($this->input->post('submit') != ''){
        $results=$this->mymodel->add_profilefileds_m($this->input->post());
        if($results==1){

         $this->session->set_flashdata('success', 'Data is added successfully');
            redirect(base_url('admin/list_profilefileds'));
        }
      }
     }
     
      $this->load->view('admin/includes/header');
      $this->data['message']=$this->load->view('admin/includes/message',$this->data,TRUE);
      $this->load->view('admin/add_profilefileds',$this->data);
      $this->load->view('admin/includes/footer');

     }

   
     

     public function profilefileds_status($id,$status){
       $results=$this->mymodel->profilefileds_status_m($id,$status);
       if($results==1){

         $this->session->set_flashdata('success', 'status changed successfully');
            redirect(base_url('admin/list_profilefileds'));
        }

     }
     public function edit_profilefileds($id){
      
        $this->data['datashow']=$this->mymodel->edit_profilefileds_m($id);
        $this->load->view('admin/includes/header');
      $this->data['message']=$this->load->view('admin/includes/message',$this->data,TRUE);
        $this->load->view('admin/edit_profilefileds',$this->data);
        $this->load->view('admin/includes/footer');
      } 

      public function update_profilefileds(){
        $id=$this->input->post('id');
        $filedname=$this->input->post('filedname');
        $aftercheck=$this->mymodel->up_check_profilefileds_m($id,$filedname);
        if($aftercheck){
      $this->session->set_flashdata('error', 'This this Name already exists');
            redirect(base_url('admin/edit_profilefileds/'.$id));
     }
     else{
        if($this->input->post('update') !=''){
          $results=$this->mymodel->update_profilefileds_m($this->input->post());
          if($results==1){

         $this->session->set_flashdata('success', 'Data is Updated successfully');
            redirect(base_url('admin/list_profilefileds'));
        }
        }

      }
    }

      public function deletestau_profilefileds($id,$delete_status){
       $results= $this->mymodel->deletestau_profilefileds_m($id,$delete_status);
        if($results==1){

         $this->session->set_flashdata('success', 'Data is Deleted successfully');
            redirect(base_url('admin/list_profilefileds'));

      }
    }



      public function list_profiledetials(){
      $this->data['profiledata']=$this->mymodel->list_profiledetials_m();
      $this->load->view('admin/includes/header');
      $this->data['message']=$this->load->view('admin/includes/message',$this->data,TRUE);
      $this->load->view('admin/list_profiledetials',$this->data);
      $this->load->view('admin/includes/footer');
    }

    
    public function add_profiledetials(){
     if($this->input->post('submit') !=''){
      $results=$this->mymodel->add_profiledetials_m($this->input->post());
         if($results==1){

         $this->session->set_flashdata('success', 'Data is added successfully');
            redirect(base_url('admin/list_profiledetials'));

      }

     }
     $this->data['filedata']=$this->mymodel->list_active_profilefileds_m();

      $this->load->view('admin/includes/header');
      $this->data['message']=$this->load->view('admin/includes/message',$this->data,TRUE);
      $this->load->view('admin/add_profiledetials',$this->data);
      $this->load->view('admin/includes/footer');

    }

     public function profiledetials_status($id,$status){
      $results=$this->mymodel->profiledetials_status_m($id,$status);
      if($results==1){
        $this->session->set_flashdata('success', 'Status is Changed successfully');
            redirect(base_url('admin/list_profiledetials'));
      }


    }

    public function edit_profiledetials($id){
    $this->data['profiledata']=$this->mymodel->list_profilefileds_m();
    //echo'<pre>';print_r($this->data['profiledata']); exit;
     $this->data['editprdt']=$this->mymodel->edit_profiledetials_m($id);
      
       $this->load->view('admin/includes/header');
      $this->data['message']=$this->load->view('admin/includes/message',$this->data,TRUE);
      $this->load->view('admin/edit_profiledetials',$this->data);
      $this->load->view('admin/includes/footer');
    }
    public function upadte_profiledetials(){

      if($this->input->post('update')!==''){
        $results=$this->mymodel->upadte_profiledetials_m($this->input->post());
        if($results==1){
           $this->session->set_flashdata('success', 'Update is successfully');
            redirect(base_url('admin/list_profiledetials'));
        }
      }

    }

     public function delete_status_profiledetials($id,$delete_status){
      $results=$this->mymodel->deletestau_profiledetials_m($id,$delete_status);
      if($results==1){
        $this->session->set_flashdata('success', 'Data is Delete successfully');
            redirect(base_url('admin/list_profiledetials'));
      }

     }

/*     public function list_achievements_content(){
      
      $this->load->view('admin/includes/header');
      $this->load->view('admin/list_achievements_content');
      $this->load->view('admin/includes/footer');
     }*/
     

     public function add_achievements_content(){
      
      //echo '<pre>'; print_r($this->input->post()); exit;
      if($this->input->post('submit')!=''){

          if($_FILES['image']['name'] !=''){
          $config['upload_path']          = './assets/images/achievements';
          $config['allowed_types']        = 'pdf|jpg|png|gif';
          $config['max_size']             = 2000;
          $this->load->library('upload', $config);
          if(! $this->upload->do_upload('image'))
          {
          $data['msg'] = $this->upload->display_errors();
          $this->session->set_flashdata('error', $data['msg']);
          redirect(base_url().'admin/add_achievements_content/');

          }else{

          $imgdata = $this->upload->data();
          $image = 'assets/images/achievements/'.$imgdata['file_name'];

          }

  }



        $titles=$this->input->post('titles');

       //echo '<pre>'; print_r($_POST); exit;
        $result=$this->mymodel->add_achievements_content_m($image,$titles);
        if($result==1){
        $this->session->set_flashdata('success', 'Data is added successfully');
            redirect(base_url('admin/list_achievements_content'));
      }


      }


      $this->load->view('admin/includes/header');
      $this->data['message']=$this->load->view('admin/includes/message',$this->data,TRUE);
      $this->load->view('admin/add_achievements_content',$this->data);
      $this->load->view('admin/includes/footer');

     }
     public function list_achievements_content(){
     	$this->data['showdata']=$this->mymodel->list_achievements_content_m();

     $this->load->view('admin/includes/header');
      $this->data['message']=$this->load->view('admin/includes/message',$this->data,TRUE);
      $this->load->view('admin/list_achievements_content',$this->data);
      $this->load->view('admin/includes/footer');

     }
     public function achievements_content_status($id,$status){

     	$results=$this->mymodel->achievements_content_status_m($id,$status);
     	   if($results==1){
        $this->session->set_flashdata('success', 'Status is Changed successfully');
            redirect(base_url('admin/list_achievements_content'));
      }

     }
     public function edit_achievements_content($id){
        $this->data['editdata']=$this->mymodel->edit_achievements_content_m($id);
        $this->data['titles']=$this->mymodel->get_titles_m($id);

       $this->load->view('admin/includes/header');
      $this->data['message']=$this->load->view('admin/includes/message',$this->data,TRUE);
      $this->load->view('admin/edit_achievements_content',$this->data);
      $this->load->view('admin/includes/footer');
     }

     public function update_achievements_content(){

       $id=$this->input->post('id');
       $titles=$this->input->post('titles');
       $rowdata=$this->mymodel->edit_achievements_content_m($id);
       //echo '<pre>'; print_r($id); exit;
       if($this->input->post('update')!=''){
        if($_FILES['image']['name'] !=''){

		$config['upload_path']          = './assets/images/achievements';
		$config['allowed_types']        = 'pdf|jpg|png|gif';
		$config['max_size']             = 2000;
		$this->load->library('upload', $config);

			if(! $this->upload->do_upload('image'))
			{
					$data['msg'] = $this->upload->display_errors();
					$this->session->set_flashdata('error', $data['msg']);
					redirect(base_url().'admin/edit_achievements_content/'.$id);

			}else{
			
			$imgdata = $this->upload->data();
			$image = 'assets/images/achievements/'.$imgdata['file_name'];

			$file = './'.$rowdata['image'];
			if(is_file($file));
			unlink($file);

			}
		}else{
			$image = $rowdata['image'];
		}

		//echo'<pre>'; print_r($image); exit;
     $results=$this->mymodel->update_achievements_content_m($image,$id,$titles);
     if($results==1){
     	$this->session->set_flashdata('success', 'Data is Updated successfully');
            redirect(base_url('admin/edit_achievements_content/'.$id));

     }

    
     }
 }

     public function achievements_delete_title($content_id,$id){
      
     $results=$this->mymodel->achievements_delete_title_m($id);
     if($results==1){
     	$this->session->set_flashdata('success', 'Data Removed successfully');
            redirect(base_url('admin/edit_achievements_content/'.$content_id));
     }

     }
     public function add_achievementsgallery(){
           


     	if($this->input->post('submit')!=''){

     		
     		$images=$_FILES;
        foreach($images as $key=>$image){

        //echo '<pre>';print_r($_FILES);exit;

          if($_FILES['image']['name'] !=''){
          $config['upload_path']          = './assets/images/achievements/gallery';
          $config['allowed_types']        = 'pdf|jpg|png|gif';
          $config['max_size']             = 2000;
          $this->load->library('upload', $config);
          if(! $this->upload->do_upload('image'))
          {
          $data['msg'] = $this->upload->display_errors();
          $this->session->set_flashdata('error', $data['msg']);
          redirect(base_url().'admin/add_achievementsgallery');

          }else{

          $imgdata = $this->upload->data();
          $image = 'assets/images/achievements/gallery/'.$imgdata['file_name'];

          }
         echo $image; exit;
          }
      }
 
     	}
     	
      $this->load->view('admin/includes/header');
      $this->data['message']=$this->load->view('admin/includes/message',$this->data,TRUE);
      $this->load->view('admin/add_achievementsgallery',$this->data);
      $this->load->view('admin/includes/footer');

     }
/*    public function emailsend(){
    	
		$this->load->library('email');
		$this->email->from('vmk4692@gmail.com', 'Murali Krishna');
		$this->email->to('vmk4692@gmail.com');
		$this->email->cc('another@another-example.com');
		$this->email->bcc('them@their-example.com');

		$this->email->subject('Email Test');
		$this->email->message('Testing the email class.');

		$results=$this->email->send();
		echo $results;
    }*/




      public function list_vision(){

     $this->data['showdata']=$this->mymodel->list_vision_m();

       $this->load->view('admin/includes/header');
       $this->data['message']=$this->load->view('admin/includes/message',$this->data,TRUE);
       $this->load->view('admin/list_vision',$this->data);
       $this->load->view('admin/includes/footer');

     }
         public function add_vision(){
       
      if($this->input->post('submit')!=''){
    
     $results=$this->mymodel->add_vision_m($this->input->post());
     if($results==1){
      $this->session->set_flashdata('success', 'Data Added successfully');
            redirect(base_url('admin/list_vision/'));
     }
    
      
      }
       

       $this->load->view('admin/includes/header');
       $this->data['message']=$this->load->view('admin/includes/message',$this->data,TRUE);
       $this->load->view('admin/add_vision',$this->data);
       $this->load->view('admin/includes/footer'); 

    }

    public function status_vision($id,$status){
    $results=$this->mymodel->status_vision_m($id,$status);
      if($results==1){
      $this->session->set_flashdata('success', 'Status Changed  successfully');
            redirect(base_url('admin/list_vision/'));
     }
    }

    public function edit_vision($id){

      $this->data['showdata']=$this->mymodel->edit_vision_m($id);

      $this->load->view('admin/includes/header');
      $this->data['message']=$this->load->view('admin/includes/message',$this->data,TRUE);
      $this->load->view('admin/edit_vision',$this->data);
      $this->load->view('admin/includes/footer');

    }

    public function update_vision(){

      if($this->input->post('update') != ''){
        $id=$this->input->post('id');
      }

    }

  

}

?>