<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_login extends CI_Controller

{
  function __construct()

  {

    parent::__construct();  
  //echo '123';exit;

      $this->load->model('Adminloginmodel','mymodel');
      $this->load->model('Common_model','common_model');
   

}

  
  public function index()
  {
    $user=$this->input->post('user');
    $pass=$this->input->post('password');
    

      if($this->input->post('submit')!=''){
        //echo $user; exit;
        $results=$this->mymodel->login_m($user,$pass);

        if(!empty($results)){
           $this->mymodel->login_update($results);
           $user_data = $this->session->all_userdata();
           //echo '<pre>';print_r($user_data);exit;
       //echo 'well';
    redirect(base_url('admin/list_sociallinks'));
       
        }
        else{
           $this->session->set_flashdata('success', 'Please check your email verify the mail link...' );
        }

      }
      //$data['login']=
      $this->load->view('admin/includes/loginheader');
    $this->load->view('admin/loginview');
    $this->load->view('admin/includes/footer');
  }



public function logout()
{
  
    $user_data = $this->session->all_userdata();
    //echo '<pre>'; print_r($user_data); exit;
        foreach ($user_data as $key => $value) {
            if ($key != 'session_id' && $key != 'ip_address' && $key != 'user_agent' && $key != 'last_activity') {
                $this->session->unset_userdata($key);
            }
        }
    $this->session->sess_destroy();
    redirect('admin_login');
}





     
     public function forgot_password()
     {

      if($this->input->post('submit')!='')
          {

            $email=$this->input->post('email');
            //echo $email;exit;
            $results=$this->mymodel->check_email_m($email);

            /*if($results){
              redirect(base_url('admin/update_password'));
            }else{
            echo'not here';
            }*/
            
            if(!empty($results)){
            $admin_id=$results['id'];
            $body=$this->common_model->AdminForgot_password('5',$admin_id);
            $to=$email;
            $template=$body;
            $name='admin';
            $reason='Admin password verification link';
            $sent=$this->common_model->mail_send($to,$template,$name,$reason);
            //echo '<pre>';print_r($sent);exit;
             $this->session->set_flashdata('success', 'Please check your email verify the mail link...' );


            }else{                             
                
            $this->session->set_flashdata('error', 'Invaild email...' );
            redirect(base_url('admin/forgot_password'));
            }
            
          // redirect(base_url('admin/update_password/'.$id));
          
        
          }

    $this->load->view('admin/includes/loginheader');
    $this->load->view('admin/forgot_password');
    $this->load->view('admin/includes/footer');
     }

     public function update_password($id=1)
     {
      $cpass=$this->input->post('password1');
      if($this->input->post('submit')){
       //echo $id; exit;
        $results=$this->mymodel->update_pass_m($cpass,$id);
        if($results==1){
            $this->session->set_flashdata('success', 'Your Password Changed successfully');
            redirect(base_url('admin/update_password'));
        }else{
          $this->session->set_flashdata('error', 'Your Password Not Changed');
        }

      }
    
     
     //echo $pass;
     // $cpass;
      $this->load->view('admin/includes/header');
      $this->load->view('admin/update_password');
      $this->load->view('admin/includes/footer');
      }


   
}
?>