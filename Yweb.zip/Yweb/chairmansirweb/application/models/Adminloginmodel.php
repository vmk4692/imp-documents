<?php

defined('BASEPATH') OR exit('No direct script access allowed');


class Adminloginmodel extends CI_Model

{ 
	public $tbl_admins='tbl_admins';
	public $tbl_admin_login_history='tbl_admin_loginhistory'; 
	public $tbl_social_links='tbl_social_links';

	public function login_m($user,$pas)

	{
		///echo '<pre>'; print_r($this->tbl_admins); exit;
		
		$this->db->select('*');
		$this->db->from($this->tbl_admins);
		$this->db->where('user',$user);
		$this->db->where('password',md5($pas));
		$query=$this->db->get();
		//echo '<pre>'; print_r($query); exit;
		//echo $this->db->last_query(); exit;
		$results=$query->row_array();
		return $results;

    }

	public function login_update($result){


		$update_ary=array(
							'lastlogin_date'=>date('Y-m-d H:i:s')
		             	 );

		$this->db->update($this->tbl_admins,$update_ary,array('id'=>$result['id']));

		$ip_address=$this->input->ip_address();
		$browser_name=$_SERVER['HTTP_USER_AGENT'];

		$insert_array=array(
			'admin_id'=>$result['id'],
			'login_date'=>date('Y-m-d'),
			'login_time'=>date('H:i:s'),
			'ip_address'=>$ip_address,
			'browser_name'=>$browser_name,
			'created_on'=>date('Y-m-d H:i:s'),
		);

		$this->db->insert($this->tbl_admin_login_history,$insert_array);
		$login_history_id=$this->db->insert_id();

		if($result){
				//set session values here
				$this->session->set_userdata('admin_id', $result['id']);
				$this->session->set_userdata('user_type', '1');
				$this->session->set_userdata('login_history_id', $login_history_id);
				$this->session->set_userdata('logged_in', "ADMIN");
				$this->session->set_userdata('login_state', TRUE);
				//$user_data = $this->session->all_userdata();
				
			}
	    


		
		//echo '<pre>';print_r($insert_array);exit;

	}
           public function check_email_m($email){
                 //echo $email;exit;
				$this->db->select('*');
				$this->db->from($this->tbl_admins);
				$this->db->where('email',$email);
				$query=$this->db->get();
				$results=$query->row_array();
				return $results;
				//echo '<pre>';print_r($results);exit;

			}

			public function update_pass_m($cpass,$id){
				$update=array(
					'password'=>md5($cpass),
				);
				$results=$this->db->update($this->tbl_admins,$update,array('id'=>$id));
				return $results;

			}
			public function list_sociallinks_m(){
				$this->db->select('*');
				$this->db->from($this->tbl_social_links);
				$query=$this->db->get();
				$results=$query->result_array();
				return $results;
				//echo '<pre>'; print_r($results); exit;
			}
			public function edit_sociallinks_m($id){
               
               $this->db->select('*');
               $this->db->from($this->tbl_social_links);
               $this->db->where('id',$id);
               $query=$this->db->get();
			   $results=$query->row_array();
			   //echo '<pre>'; print_r($results); exit;
				return $results;
			}

			public function update_sociallinks_m($update){
                 $id=$update['id'];
				$updates=array(
                 'facebook_link'=>$update['facebook_link'],
                 'twitter_link'=>$update['twitter_link'],
                 'youtube_link'=>$update['youtube_link'],
                 'instagram_link'=>$update['instagram_link'],
                 'modified_on' => date('Y-m-d H:i:s')


				);
				$results=$this->db->update($this->tbl_social_links,$updates,array('id'=>$id));
				return $results;

			}

            

}


?>