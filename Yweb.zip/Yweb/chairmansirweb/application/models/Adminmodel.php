 <?php

defined('BASEPATH') OR exit('No direct script access allowed');


class Adminmodel extends CI_Model

{ 
	public $tbl_admins='tbl_admins';
	public $tbl_admin_login_history='tbl_admin_loginhistory'; 
	public $tbl_social_links='tbl_social_links';
	public $tbl_about='tbl_about';
	public $tbl_profilefileds='tbl_profilefileds';
	public $tbl_profiledetials='tbl_profiledetials';
	public $tbl_achievements_content='tbl_achievements_content';
	public $tbl_achievements_content_details='tbl_achievements_content_details';
  public $tbl_vision='tbl_vision';

	public function login_m($user,$pas)

	{
		///echo '<pre>'; print_r($this->tbl_admins); exit;
		
		$this->db->select('*');
		$this->db->from($this->tbl_admins);
		$this->db->where('user',$user);
		$this->db->where('password',md5($pas));
		$query=$this->db->get();
		//echo '<pre>'; print_r($query); exit;
		//echo $this->db->last_query(); exit;
		$results=$query->row_array();
		return $results;

    }

	public function login_update($result){


		$update_ary=array(
							'lastlogin_date'=>date('Y-m-d H:i:s')
		             	 );

		$this->db->update($this->tbl_admins,$update_ary,array('id'=>$result['id']));

		$ip_address=$this->input->ip_address();
		$browser_name=$_SERVER['HTTP_USER_AGENT'];

		$insert_array=array(
			'admin_id'=>$result['id'],
			'login_date'=>date('Y-m-d'),
			'login_time'=>date('H:i:s'),
			'ip_address'=>$ip_address,
			'browser_name'=>$browser_name,
			'created_on'=>date('Y-m-d H:i:s'),
		);

		$this->db->insert($this->tbl_admin_login_history,$insert_array);
		$login_history_id=$this->db->insert_id();

		if($result){
				//set session values here
				$this->session->set_userdata('admin_id', $result['id']);
				$this->session->set_userdata('user_type', '1');
				$this->session->set_userdata('login_history_id', $login_history_id);
				$this->session->set_userdata('logged_in', "ADMIN");
				$this->session->set_userdata('login_state', TRUE);
				//$user_data = $this->session->all_userdata();
				
			}
	    


		
		//echo '<pre>';print_r($insert_array);exit;

	}
           public function check_email_m($email){
                 //echo $email;exit;
				$this->db->select('*');
				$this->db->from($this->tbl_admins);
				$this->db->where('email',$email);
				$query=$this->db->get();
				$results=$query->row_array();
				return $results;
				//echo '<pre>';print_r($results);exit;

			}

			public function update_pass_m($cpass,$id){
				$update=array(
					'password'=>md5($cpass),
				);
				$results=$this->db->update($this->tbl_admins,$update,array('id'=>$id));
				return $results;

			}
			public function list_sociallinks_m(){
				$this->db->select('*');
				$this->db->from($this->tbl_social_links);
				$query=$this->db->get();
				$results=$query->result_array();
				return $results;
				//echo '<pre>'; print_r($results); exit;
			}
			public function edit_sociallinks_m($id){
               
               $this->db->select('*');
               $this->db->from($this->tbl_social_links);
               $this->db->where('id',$id);
               $query=$this->db->get();
			   $results=$query->row_array();
			   //echo '<pre>'; print_r($results); exit;
				return $results;
			}

			public function update_sociallinks_m($update){
                 $id=$update['id'];
				$updates=array(
                 'facebook_link'=>$update['facebook_link'],
                 'twitter_link'=>$update['twitter_link'],
                 'youtube_link'=>$update['youtube_link'],
                 'instagram_link'=>$update['instagram_link'],
                 'modified_on' => date('Y-m-d H:i:s')


				);
				$results=$this->db->update($this->tbl_social_links,$updates,array('id'=>$id));
				return $results;

			}

			public function list_about_m(){
				$this->db->select('*');
				$this->db->from($this->tbl_about);
				$this->db->where('delete_status','1');
				$query=$this->db->get();
				$results=$query->result_array();
				return $results;
				//echo '<pre>'; print_r($results); exit;


			}
			public function add_about_m($insert){
			 //echo '<pre>'; print_r($insert); exit;
			$results=$this->db->insert($this->tbl_about,$insert); 

			return $results;

			}
			public function update_status_m($id, $status){
				
				if($status=='Active'){
					$ups='Inactive';
				}
				elseif($status=='Inactive'){
					$ups='Active';
				}
				$dataupstu=array(
                  'status'=>$ups,
				);

				$dataupstu['modified_on']=date('Y-m-d H:i:s');
				$results=$this->db->update($this->tbl_about,$dataupstu,array('id'=>$id));
				return $results;

			}

			public function edit_about_m($id){
				$this->db->select('*');
				$this->db->from($this->tbl_about);
				$this->db->where('id',$id);
				$query=$this->db->get();
				$results=$query->row_array();
				return $results;


			}
			public function update_about_m($update_data,$image){

				//echo '<pre>'; print_r($update_data); exit;

                 $id=$update_data['id'];
				 $updatedata=array(
                 'title'=>$update_data['title'],
                 'content'=>$update_data['content'],
                 'image'=>$image,
                 'modified_on'=>date('Y-m-d H:i:s')
				);
				
		    $results=$this->db->update($this->tbl_about,$updatedata,array('id'=>$id));
		    return $results;

				

			}
			public function delete_status_m($id,$delete_status){

                    //echo $delete_status; exit;

				if($delete_status['delete_status']=='1'){
					$updelestu='0';

				}
				else if($delete_status['delete_status']=='0'){
					$updelestu='1';
				}

		

			$upd=array(
             'delete_status'=>$updelestu,
             'modified_on'=>date('Y-m-d H:i:s')
            );

            $results=$this->db->update($this->tbl_about,$upd,array('id'=>$id));
            return $results;


           	}


           	public function list_profilefileds_m(){
           		$this->db->select('*');
				$this->db->from($this->tbl_profilefileds);
				$this->db->where('delete_status','1');
				$query=$this->db->get();
				$results=$query->result_array();
				return $results;
           	}

           	public function add_profilefileds_m($postvalue){
                   
                   //echo '<pre>'; print_r($postvalue); exit;
                  $insert_array=array(
                   'filedname'=>$postvalue['filedname'],
                   'created_on'=>date('Y-m-d H:i:s')

                  );
            $results= $this->db->insert($this->tbl_profilefileds,$insert_array);
            return $results;

           	}

           	public function profilefileds_status_m($id,$status){
              
              if($status=='Active'){
              	$stu='Deactive';
              }
              else if($status=='Deactive'){
              	$stu='Active';
              }
              $s_up=array(
              'status'=>$stu,
              'modified_on'=>date('Y-m-d H:i:s')
              );
              $results=$this->db->update($this->tbl_profilefileds,$s_up,array('id'=>$id));
              return $results;


            }


            public function edit_profilefileds_m($id){
            	$this->db->select('*');
            	$this->db->from($this->tbl_profilefileds);
            	$this->db->where('id',$id);
            	$query=$this->db->get();
            	$results=$query->row_array();
            	return $results;

            }
            public function update_profilefileds_m($postval){
            
             $id=$postval['id'];
              //echo $id;
             $up_date=array(
             'filedname'=>$postval['filedname'],
             'modified_on'=>date('Y-m-d H:i:s')
            );
             //echo '<pre>'; print_r($up_date); exit;
            $results=$this->db->update($this->tbl_profilefileds,$up_date,array('id'=>$id));
             return $results;
            }


            public function deletestau_profilefileds_m($id,$delete_status){
            	if($delete_status=='1'){
            		$d_stu='0';
            	}
            	$up_arr=array(
            	'delete_status'=>$d_stu,
            	);
           $results=$this->db->update($this->tbl_profilefileds,$up_arr,array('id'=>$id));
             return $results;
            }


            public function list_profiledetials_m(){
            $this->db->select('tbl_profiledetials.*,tbl_profilefileds.filedname as fname');
				$this->db->from($this->tbl_profiledetials);

				$this->db->join('tbl_profilefileds','tbl_profiledetials.filed_id=tbl_profilefileds.id','inner');
                $this->db->where('tbl_profiledetials.delete_status','1');
				$query=$this->db->get();
				$results=$query->result_array();
				return $results;
            }
            public function add_check_profilefileds_m($filedname){
            	$this->db->select('*');
            	$this->db->from($this->tbl_profilefileds);
            	$this->db->where('filedname',$filedname);
            	$this->db->where('delete_status','1');
            	$query=$this->db->get();
            	$results=$query->row_array();
            	return $results;

            }

            public function up_check_profilefileds_m($id,$filedname){
            	$this->db->select('*');
            	$this->db->from($this->tbl_profilefileds);
            	$this->db->where('filedname',$filedname);
            	$this->db->where('delete_status','1');
            	$this->db->where('id !=',$id);
            	$query=$this->db->get();
            	$results=$query->row_array();
            	return $results;
            }
            public function add_profiledetials_m($postval){
               
              //echo '<pre>'; print_r($postval); exit;


            	$insert=array(
            	'filed_id'=>$postval['filed_id'],
                'description'=>$postval['description'],
                'place_order'=>$postval['place_order'],
                 'created_on'=>date('Y-m-d H:i:s')
            	);
                //echo '<pre>'; print_r($insert); exit;
            	$results=$this->db->insert($this->tbl_profiledetials,$insert);
            	return $results;


            }
            public function list_active_profilefileds_m(){
            	$this->db->select('*');
            	$this->db->from($this->tbl_profilefileds);
            	$this->db->where('status','Active');
            	$this->db->where('delete_status','1');
            	$query=$this->db->get();
            	$results=$query->result_array();
            	//echo '<pre>'; print_r($results); exit;
            	return $results;
            }

            public function profiledetials_status_m($id,$status){
              
              if($status=='Active'){
              	$stu='Deactive';
              }
              else if($status=='Deactive'){
              	$stu='Active';
              }
              $s_up=array(
              'status'=>$stu,
              'modified_on'=>date('Y-m-d H:i:s')
              );
        $results=$this->db->update($this->tbl_profiledetials,$s_up,array('id'=>$id));
        return $results;


            }

            public function edit_profiledetials_m($id){
            	
             $this->db->select('*');
            	$this->db->from($this->tbl_profiledetials);
            	$this->db->where('id',$id);
            	$this->db->where('delete_status','1');
            	$query=$this->db->get();
            	$results=$query->row_array();
            	return $results;
            }

            public function upadte_profiledetials_m($postval){
            	$id=$postval['id'];
            	//echo'<pre>'; print_r($postval); exit;
            	$update=array(
                 'place_order'=>$postval['place_order'], 
                 'filed_id'=>$postval['filed_id'],
                 'description'=>$postval['description'],
                 'modified_on'=>date('Y-m-d H:i:s')
            	);
      $results=$this->db->update($this->tbl_profiledetials,$update,array('id'=>$id));
      return $results;

            }


             public function deletestau_profiledetials_m($id,$delete_status){
            	if($delete_status=='1'){
            		$d_stu='0';
            	}
            	$up_arr=array(
            	'delete_status'=>$d_stu,
            	);
           $results=$this->db->update($this->tbl_profiledetials,$up_arr,array('id'=>$id));
             return $results;
            }
            public function add_achievements_content_m($image,$titles){
            	
            	$insertimg=array(
          		'image '=>$image, 
         		'created_on'=>date('Y-m-d H:i:s'),
				);

            	$result=$this->db->insert($this->tbl_achievements_content,$insertimg);
        //echo'<pre>'; print_r($result); exit;
            	$last_id=$this->db->insert_id();

            	foreach($titles as $title){
		        	$t_arry=array(
		        	'content_id'=>$last_id, 
		      		'title '=>$title
		     		);
		     	  $result=$this->db->insert($this->tbl_achievements_content_details,$t_arry);
            
            	}

            	
            	return $result;

            }


            public function list_achievements_content_m(){
              $this->db->select('*');
              $this->db->from($this->tbl_achievements_content);
              $this->db->where('delete_status','1');
              $query=$this->db->get();
              $results=$query->result_array();
              //echo'<pre>'; print_r($results); exit;
              return $results;


            }


            public function achievements_content_status_m($id,$status){

              if($status=='Active'){
                $stu='Deactive';
              }
              else if ($status=='Deactive') {
                $stu='Active';
              }
              $up=array(
               'status'=>$stu,
               'modified_on'=>date('Y-m-d H:i:s')
              );
            $results=$this->db->update($this->tbl_achievements_content,$up,array('id'=>$id));
            return $results;

            }

            public function edit_achievements_content_m($id){

                $this->db->select('*');
              $this->db->from($this->tbl_achievements_content);
              $this->db->where('id',$id);
              $query=$this->db->get();
              $results=$query->row_array();
              //echo'<pre>'; print_r($results); exit;
              return $results;
            }

            public function get_titles_m($id){
               $this->db->select('*');
              $this->db->from($this->tbl_achievements_content_details);
              $this->db->where('content_id',$id);
              $query=$this->db->get();
              $results=$query->result_array();
              //echo'<pre>'; print_r($results); exit;
              return $results;
            }

            public function update_achievements_content_m($path,$id,$titles){
              //echo'<pre>'; print_r($titles); exit;

              $upd=array(
              'image'=>$path,
              'modified_on'=>date('Y-m-d H:i:s')
              );
             $results=$this->db->update($this->tbl_achievements_content,$upd,array('id'=>$id));
            
          $this->db->delete($this->tbl_achievements_content_details,array('content_id'=>$id));
             
          foreach($titles as $title){
              $t_arry=array(
              'content_id'=>$id, 
              'title '=>$title
            );
            $result=$this->db->insert($this->tbl_achievements_content_details,$t_arry);
            }
 
              return $result;

            }


            public function achievements_delete_title_m($id){
            $results=$this->db->delete($this->tbl_achievements_content_details,array('id'=>$id));
              return $results;

            }
            
            public function add_vision_m($postval){
              $insert=array(
                'description'=>$postval['description'],
                'created_on'=>date('Y-m-d H:i:s')
              );
            //echo'<pre>'; print_r($insert); exit;
            $results=$this->db->insert($this->tbl_vision,$insert);
            return $results;
            }

            public function list_vision_m(){
              $this->db->select();
              $this->db->from($this->tbl_vision);
              $this->db->where('delete_status','1');
              $query=$this->db->get();
              $results=$query->result_array();
              return $results;

            }
            public function status_vision_m($id,$status){
              if($status=='Active'){
                $stu='Deactive';

              }
              else if($status=='Deactive'){
                $stu='Active';

              }

              $stuup=array(
             'status'=>$stu,
              );
              $results=$this->db->update($this->tbl_vision,$stuup,array('id'=>$id));
              return $results;
              
            }

            public function edit_vision_m($id){
              $this->db->select();
              $this->db->from($this->tbl_vision);
              $this->db->where('id',$id);
              $this->db->where('delete_status','1');
              $query=$this->db->get();
              $results=$query->row_array();
              return $results;

            }

}


?>