<?php

defined('BASEPATH') OR exit('No direct script access allowed');


class Common_model extends CI_Model

{ 
	public $email_templates='tbl_email_templates';
	public $web_table_name='tbl_web_settings';
	public $table_social_links='tbl_social_links';


	public function setMailHeaderTemplate()

	{
		
		$this->db->select('*');
		$this->db->from($this->email_templates);
		$this->db->where('page_name','header');
		$query=$this->db->get();
		$result=$query->row_array();
		return $result['content'];

    }

    public function setMailFooterTemplate()

	{
		$this->db->select('*');
		$this->db->from($this->email_templates);
		$this->db->where('page_name','footer');
		$query=$this->db->get();
		$result=$query->row_array();
		return $result['content'];

    }

    public function setMailBodyTemplate($id){
    	$this->db->select('*');
		$this->db->from($this->email_templates);
		$this->db->where('id',$id);
		$query=$this->db->get();
		$result=$query->row_array();
		return $result;
    }

    public function getWebSettings(){
		$this->db->select('*');
		$this->db->from($this->web_table_name);
		$this->db->where('id',1);		
		$result=$this->db->get();
		return $result->row_array();
	}

	/** Function to get Social Links **/	
	public function get_social_links(){
        $this->db->select("*");
		$this->db->from($this->table_social_links);
		$this->db->where('id',1);		
		//$this->db->where('status = ', 1);
		$query = $this->db->get();
		//echo $this->db->last_query();
		$result = $query->row_array();
		return $result;
	}
	/** Function to get  Mail Template Footer **/
	public function getMailFooter(){
		$mailFoot		= 	$this->setMailFooterTemplate();
		$social		= 	$this->get_social_links();
		$thanks_regards	=	str_replace("{ADDRESS}",$_SERVER['SERVER_NAME'],$mailFoot);
		$website		=	str_replace("{WEBSITE}",site_url(),$thanks_regards);
		$folder			=	str_replace("{FOLDER}",'images',$website);

		$facebook_link	=	str_replace("{FACEBOOK}",$social['facebook_link'],$folder);
		$twitter_link	=	str_replace("{TWITTER}",$social['twitter_link'],$facebook_link);
		$googleplus_link=	str_replace("{GOOGLEPLUS}",$social['google_plus_link'],$twitter_link);
		$youtube_link	=	str_replace("{YOUTUBE}",$social['youtube_link'],$googleplus_link);
		$result = $youtube_link;
		//print_r($result);
		return $result;
	}
/** Function to get  Mail Template Header **/
	public function getMailHeader(){
		$mailHead	= 	$this->setMailHeaderTemplate();
		$logo		= 	$this->getWebSettings();
		$contact	= 	$this->getWebSettings();
		//echo '<pre>';print_r($webSetting);exit;
		$website	=	str_replace("{WEBSITE}",site_url(),$mailHead);
		$folder		=	str_replace("{FOLDER}",'assets/admin/images/logo/',$website);
		$logo		=	str_replace("{LOGO}",$logo['logo'],$folder);
		//echo '<pre>';print_r($logo);exit;
		$email		=	str_replace("{EMAIL}",$contact['mail_template_admin_email'],$logo);
		$phone		=	str_replace("{PHONE}",$contact['mail_template_admin_mobile'],$email);
		$result = $phone;
		//print_r($result);
		return $result;
	}

   public function AdminForgot_password($themeid,$admin_id){

		$mailBody	= 	$this->setMailBodyTemplate($themeid);
		
		$name='Admin';
		$url = base_url().'admin/update_password/'.$admin_id;	
       	$name		=	str_replace("{NAME}",$name,$mailBody);
		$url		=	str_replace("{URL}",$url,$name);
		$result = $url;
		//echo'<pre>';print_r($result);exit;
		return $result;
	}

	public function mail_send($to,$template,$name,$reason){

	   $adminmail = $this->getWebSettings();
	   $current_ip_address =  $_SERVER['REMOTE_ADDR'];	
		
		
		$header = $this->getMailHeader();
		$footer = $this->getMailFooter();
		$content=$header.$template['content'].$footer;
		//echo '<pre>';print_r($content);exit;
		
		
		$this->load->library('email');
		$this->email->from($adminmail['mail_template_admin_email']);
		$this->email->to($to);
		$this->email->set_mailtype("html");
		$this->email->subject($template['subject']);
		$this->email->message($content);
		//$this->email->attach($pdfFilePath);
		if($this->email->send()){
			$record_data = array(
			'name' => $name,
			'event' => $template['event'],
			'subject' => $template['subject'],
			'email_message' =>$template['content'],
			'sent_date_time'=> date('y-m-d H:i:s'),
			'email'=>$to,
			'ip_address' =>$current_ip_address,
			'browser_name' =>$_SERVER['HTTP_USER_AGENT'],
			);
			$result = $this->db->insert('tbl_email_history_online', $record_data);
		   return 1;
		}else{ 
			$event=$template['event'].'==>'.'<b style="color:red;">FAILED</b>';
		$record_data = array(
			'name' => $name,
			'event' => $event,
			'subject' => $template['subject'],
			'email_message' =>  $template['content'],
			'email'=>$to,
			'sent_date_time'=> date('y-m-d H:i:s'),
			'ip_address' =>$current_ip_address,
			'browser_name' =>$_SERVER['HTTP_USER_AGENT'],
			);
			$result = $this->db->insert('tbl_email_history_online', $record_data);
			
			return 0;
		}
	}

/*	public function mail_send2(){
		$this->load->library('email');
		$this->email->from('vmk4692@gmail.com');
		$this->email->to('vmk4692@gmail.com');
		$this->email->set_mailtype("html");
		$this->email->subject('test');
		$this->email->message('well');
		//$this->email->attach($pdfFilePath);
		$sent=$this->email->send();
		echo $sent;exit;
	}
*/

}


?>