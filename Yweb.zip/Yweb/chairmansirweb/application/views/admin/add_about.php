
             <div id="page-wrapper">
        <div class="container-fluid">
          <?php echo $message; ?>
        	<div class="well">
            <!-- Page Heading -->
            <h4>About</h4>
            <hr/>
            <div class="row">
                <div class="col-sm-12 col-md-12 ">
                	<form class="form-horizontal" method="post"  enctype="multipart/form-data" action="<?php echo base_url('admin/add_about'); ?>" >

<!-- <div class="form-group">
  <label class="col-md-4 control-label" for="selectbasic">Select Basic</label>
  <div class="col-md-4">
    <select id="selectbasic" name="selectbasic" class="form-control">
      <option value="1">Option one</option>
      <option value="2">Option two</option>
    </select>
  </div>
</div> -->

<div class="form-group">
  <label class="col-md-4 control-label">Title</label>
  <div class="col-md-3">
    <input class="form-control" type="text" name="title" value="" required />
  </div>
</div>

<div class="form-group">
  <label class="col-md-4 control-label">Content</label>
  <div class="col-md-3">
    <textarea class="form-control" name="content" required></textarea>
    
  </div>
</div>

<div class="form-group">
  <label class="col-md-4 control-label">Upload Image</label>
  <div class="col-md-3">
    <input  type="file" name="image" value="" required />
  </div>
</div>



<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-3">
    <input class="btn btn-success" type="submit" name="submit" value="submit" />
    <a href="<?php echo base_url('admin/list_about'); ?>" class="btn btn-default">Cancel</a>
  </div>
</div>


</form>


                 </div>   
            </div>
            <!-- /.row -->

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- /#page-wrapper -->
