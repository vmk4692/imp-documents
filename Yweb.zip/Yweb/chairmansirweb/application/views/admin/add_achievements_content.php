
<style type="text/css">
    .entry:not(:first-of-type)
{
    margin-top: 10px;
}

.glyphicon
{
    font-size: 12px;
}
.control-group{margin:50px 0 0 0;}
.btag{
margin: 0 0 6px 12px;
display: block;}
</style>

   <div id="page-wrapper">
        <div class="container-fluid">
         <?php echo $message; ?>

         
            <div class="well">
            <!-- Page Heading -->
            <h4>Add Achievements</h4>
            <hr/>

            
            <div class="col-md-4 col-md-offset-4">
                <div class="col-md-12">

    <div class="row">
       
            <div class="controls"> 
                <form role="form" autocomplete="off" method="post" action="<?php echo base_url() ?>/admin/add_achievements_content/" enctype="multipart/form-data">
                                        <div class="row">
                               <div class="form-group">
  <div class=""><b class="btag">Upload Image</b></div>
  <div class="col-md-9">
    <input class="form-control" type="file" name="image" value="" required />
  </div>
</div>
</div>
 <div class="control-group">
            <label class="control-label" for="field1">Add Title</label>
                    <div class="entry input-group col-xs-9">
                        
                        <textarea class="form-control" rows="4" cols="50" placeholder="Title" name="titles[]"></textarea>
                        <span class="input-group-btn">
                            <button class="btn btn-success btn-add" type="button">
                                <span class="glyphicon glyphicon-plus"> Add more</span>
                            </button>
                        </span>
                    </div>
        </div>
    </div>
</div>
</div>
</div>
<div class="clears"></div>
<br/>
<div class="form-group row">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-3">
    <input class="btn btn-success" type="submit" name="submit" value="submit" />
    <a href="<?php echo base_url('admin/list_achievements_content'); ?>" class="btn btn-default">Cancel</a>
  </div>
</div>
</form>
</div>
</div>
</div>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script type="">
    
    $(function()
{
    $(document).on('click', '.btn-add', function(e)
    {
        e.preventDefault();

        var controlForm = $('.controls form:first'),
            currentEntry = $(this).parents('.entry:first'),
            newEntry = $(currentEntry.clone()).appendTo(controlForm);

        newEntry.find('textarea').val('');
        controlForm.find('.entry:not(:last) .btn-add')
            .removeClass('btn-add').addClass('btn-remove')
            .removeClass('btn-success').addClass('btn-danger')
            .html('<span class="glyphicon glyphicon-minus"> Remove</span>');
    }).on('click', '.btn-remove', function(e)
    {
        $(this).parents('.entry:first').remove();

        e.preventDefault();
        return false;
    });
});

</script>