<style type="text/css">
.addbt{
    text-align: right;
    position: relative;
    left: 54px;
    top: 0;

}
.f-right{margin:5px 0;}
</style>
             <div id="page-wrapper">
        <div class="container-fluid">
          <?php echo $message; ?>

          <?php //echo'<pre>'; print_r($titles); exit; ?>
          <div class="well">
            <!-- Page Heading -->
            <h4>Add Achievements Gallery</h4>
            <hr/>
            <div class="row">
                <div class="col-sm-12 col-md-12 ">
            <form class="form-horizontal" method="post"  enctype="multipart/form-data" action="<?php echo base_url('admin/add_achievementsgallery'); ?>" >



            
            <div class="row" id="are" >
              <div id="my">
            <div class="form-group">
            <label class="col-md-4 control-label">Upload Image</label>

            <div class="col-md-3">
            <input  type="file" name="images[]" value="" class="btn btn-default" />
            <!-- <a href="#" class="btn btn-danger btn-remove f-right"><span class="glyphicon glyphicon-minus"> Remove Image</span></a> -->
            </div>

            </div>
            </div>
            </div>

                   
            <div class="col-md-3 col-md-offset-4">
                <div class="addbt"> 
            <a class="btn btn-success btn-add">
            <span class="glyphicon glyphicon-plus"> Add more Images</span>
            </a>
            </div> 
            </div>
            <div class="clears"></div> 
                            

                      
                    


<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-3">
    <input class="btn btn-success" type="submit" name="submit" value="submit" />
    <a href="<?php echo base_url('admin/'); ?>" class="btn btn-default">Cancel</a>
    <div class="clears"></div>
  </div>
</div>



</form>


                 </div>   
            </div>
            <!-- /.row -->

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- /#page-wrapper -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type="text/javascript">
$(".btn-add").click(function(){
  $("#are").append('<div class="form-group row" id="my"><label class="col-md-4 control-label">Upload Image</label><div class="col-md-3"><input  type="file" name="images[]" value="" class="btn btn-default" /></div><a class="btn btn-danger btn-remove"><span class="glyphicon glyphicon-minus"> Remove</span></a></div>')
});

</script>
<script type="text/javascript">

  $(document).on("click", ".btn-remove", function(e) {
  e.preventdefault;
  $(this).parents("#my").fadeOut(200);
});

</script>
