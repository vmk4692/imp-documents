<style type="text/css">
.addbt{
    text-align: right;
    position: relative;
    left: 154px;
    top: 0;

}
.f-right{margin:5px 0;}
</style>
             <div id="page-wrapper">
        <div class="container-fluid">
          <?php echo $message; ?>

          <?php //echo'<pre>'; print_r($titles); exit; ?>
          <div class="well">
            <!-- Page Heading -->
            <h4>Edit Achievements</h4>
            <hr/>
            <div class="row">
                <div class="col-sm-12 col-md-12 ">
                  <form class="form-horizontal" method="post"  enctype="multipart/form-data" action="<?php echo base_url('admin/update_achievements_content'); ?>" >

<!-- <div class="form-group">
  <label class="col-md-4 control-label" for="selectbasic">Select Basic</label>
  <div class="col-md-4">
    <select id="selectbasic" name="selectbasic" class="form-control">
      <option value="1">Option one</option>
      <option value="2">Option two</option>
    </select>
  </div>
</div> -->
<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-3">
    <input class="form-control" type="hidden" name="id" value="<?php echo $editdata['id']; ?>"  />
  </div>
</div>





<div class="form-group">
  <label class="col-md-4 control-label">Upload Image</label>
  <div class="col-md-3">
    <input  type="file" name="image" value="" class="btn btn-default" />
    <div><img src="<?php echo base_url(); ?>/<?php echo $editdata['image']; ?>" class="img-responsive thumbnail"></div>
    
  </div>
</div>
            

            
            <div class="row" id="are" >


            <?php foreach ($titles as $tdata){?> 
              <div id="my">
            <div class="form-group">
            <label class="col-md-4 control-label">Edit Title</label>

            <div class="col-md-3">
            <textarea class="form-control" rows="4" cols="50" placeholder="Title" name="titles[]"><?php echo $tdata['title']; ?></textarea>
            <a href="<?php echo base_url('admin/achievements_delete_title'); ?>/<?php echo $tdata['content_id']; ?>/<?php echo $tdata['id']; ?>" class="btn btn-danger btn-remove f-right"><span class="glyphicon glyphicon-minus"> Remove</span></a>
            </div>

            </div>
            </div>

            <?php }
            ?>
            
            </div>
             <div class="addbt row">       
            <div class="col-md-3 col-md-offset-4">
            <a class="btn btn-success btn-add">
            <span class="glyphicon glyphicon-plus"> Add more</span>
            </a>
            </div> 
            </div>
            <div class="clears"></div> 
                            

                      
                    


<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-3">
    <input class="btn btn-success" type="submit" name="update" value="update" />
    <a href="<?php echo base_url('admin/list_achievements_content'); ?>" class="btn btn-default">Cancel</a>
    <div class="clears"></div>
  </div>
</div>



</form>


                 </div>   
            </div>
            <!-- /.row -->

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- /#page-wrapper -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type="text/javascript">
$(".btn-add").click(function(){
  $("#are").append('<div class="form-group row" id="my"><label class="col-md-4 control-label">Add Title</label><div class="col-md-3"><textarea class="form-control" rows="4" cols="50" placeholder="Title" name="titles[]"></textarea></div><a class="btn btn-danger btn-remove"><span class="glyphicon glyphicon-minus"> Remove</span></a></div>')
});

</script>
<script type="text/javascript">

  $(document).on("click", ".btn-remove", function(e) {
  e.preventdefault;
  $(this).parents("#my").fadeOut(200);
});

</script>
