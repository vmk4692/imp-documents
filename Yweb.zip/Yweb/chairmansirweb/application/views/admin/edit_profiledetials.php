
             <div id="page-wrapper">
        <div class="container-fluid">
          <?php echo $message; ?>

          <?php //echo '<pre>'; print_r($editprdt); exit; ?>
        	<div class="well">
            <!-- Page Heading -->
            <h4>Edit Profile Details</h4>
            <hr/>
            <div class="row">
                <div class="col-sm-12 col-md-12 ">
                	<form class="form-horizontal" method="post"  enctype="multipart/form-data" action="<?php echo base_url('admin/upadte_profiledetials'); ?>" >

<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-3">
    <input class="form-control" type="hidden" name="id" value="<?php echo $editprdt['id']; ?>"  />
  </div>
</div>

<div class="form-group">
  <label class="col-md-4 control-label">Select Order</label>
    <div class="col-md-3">
<select class="form-control" name="place_order">
  <option value="<?php echo $editprdt['place_order']; ?>"><?php echo $editprdt['place_order']; ?></option>
 
  <?php for($i=1;$i<=20;$i++){ ?> 
    <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
  <?php }
  ?>
</select>
  </div>
</div>



<div class="form-group">
  <label class="col-md-4 control-label">Filed Name</label>
    <div class="col-md-3">
<select class="form-control" name="filed_id" >
  
  <?php foreach($profiledata as $data){?> 
    
    <option value="<?php echo $data['id']; ?>" 
      <?php if($data['id'] == $editprdt['filed_id']){
        echo 'selected'; }
        ?>
        >
        <?php echo $data['filedname']; ?>
          
        </option>
  <?php }
  ?>
</select>
  </div>
</div>


<div class="form-group">
  <label class="col-md-4 control-label">Filed Description</label>
  <div class="col-md-3">
    <textarea class="form-control" name="description" ><?php echo $editprdt['description']; ?></textarea>
    
  </div>
</div>





<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-3">
    <input class="btn btn-success" type="submit" name="update" value="update" />
    <a href="<?php echo base_url('admin/list_profilefileds'); ?>" class="btn btn-default">Cancel</a>
  </div>
</div>


</form>


                 </div>   
            </div>
            <!-- /.row -->

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- /#page-wrapper -->
