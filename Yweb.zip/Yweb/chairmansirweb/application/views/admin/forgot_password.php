   <style type="text/css">

       #login .text-white{padding: 13px 103px;}

       #login .container #login-row #login-column #login-box{

        height: 276px;

       }

   </style> 

    <div id="login">

        

        <div class="container">

            <div id="login-row" class="row justify-content-center align-items-center">

                <div id="login-column" class="col-md-12">

                	<div class="text-center">

                	<h3 class="text-center text-white pt-5"> Forgot Password</h3>

                </div>


                    <div id="login-box">

                        <form id="login-form" class="form" action="<?php echo base_url() ?>admin/forgot_password" method="post">

  <?php if($this->session->flashdata('success') != ''){?>
                                    <div class="alert alert-block alert-success">
                                        <button type="button" class="close" data-dismiss="alert">
                                        <i class="fa fa-close"></i>
                                        </button>
                                        <p>
                                            <i class="icon-ok"></i>
                                            <?php echo $this->session->flashdata('success')?$this->session->flashdata('success'):'';?>
                                        </p>
                                    </div>
                             <?php } ?>
                               <?php if($this->session->flashdata('error') != ''){?>
                                    <div class="alert alert-block alert-danger">
                                        <button type="button" class="close" data-dismiss="alert">
                                        <i class="fa fa-close"></i>
                                        </button>
                                        <p>
                                            <i class="icon-ok"></i>
                                            <?php echo $this->session->flashdata('error')?$this->session->flashdata('error'):'';?>
                                        </p>
                                    </div>
                             <?php } ?>

                            <h3 class="text-center text-info">Forgot Password</h3>

                           

                            <div class="form-group">

                                <label  class="text-info">Email:</label><br>

                                <input type="text" name="email"  class="form-control" required>

                            </div>

                             <br/>

                       

                             <div class="form-group">

                               

                                <input type="submit" name="submit" class="btn btn-info btn-md" value="submit">

                            </div>

                               <div id="register-link" class="text-right">

                                <a href="<?php echo base_url() ?>admin/" class="text-info">Login Here?</a>

                            </div>

                            

                         

                        </form>

                    </div>

                </div>

            </div>

        </div>

    </div>

   





