
             <div id="page-wrapper">
        <div class="container-fluid">
        	<div class="well">
            <!-- Page Heading -->
            <h4>Social Links</h4>
            <hr/>
            <div class="row">
                <div class="col-sm-12 col-md-12 ">
                	<form class="form-horizontal"  role="form">

<!-- <div class="form-group">
  <label class="col-md-4 control-label" for="selectbasic">Select Basic</label>
  <div class="col-md-4">
    <select id="selectbasic" name="selectbasic" class="form-control">
      <option value="1">Option one</option>
      <option value="2">Option two</option>
    </select>
  </div>
</div> -->

<div class="form-group">
  <label class="col-md-4 control-label">Name</label>
  <div class="col-md-3">
    <input class="form-control" type="text" name="" value="" />
  </div>
</div>

<div class="form-group">
  <label class="col-md-4 control-label">Select Basic</label>
  <div class="col-md-3">
    <input class="form-control" type="text" name="" value="" />
  </div>
</div>


<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-3">
    <input class="btn btn-success" type="submit" name="submit" value="submit" />
    <a href="<?php echo base_url('admin/list_sociallinks'); ?>" class="btn btn-default">Cancel</a>
  </div>
</div>


</form>


                 </div>   
            </div>
            <!-- /.row -->

        </div>
        <!-- /.container-fluid -->




<!-- <table class="table table-striped table-bordered table-hover" id="dataTables-example">
<thead>
<tr>
<th>Image</th>
<th>Post Title</th>
<th>Bussiness Type</th>
</tr>
</thead>
<tbody>
<tr class="odd gradeX">
<td>hfghgfh</td>
<td>hfghgfh</td>
<td>gfhgfhgfhgf</td>
</tr>
<tr class=" gradeX">
<td>1</td>
<td>2</td>
<td>3</td>
</tr>
</tbody>
</table> -->







    </div>
    <!-- /#page-wrapper -->
