
</div><!-- /#wrapper -->

<script type="text/javascript" src="<?php echo base_url().ADMIN_JS_PATH ?>/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url().ADMIN_JS_PATH ?>bootstrap/bootstrap.js"></script>

<script type="text/javascript" src="<?php echo base_url().ADMIN_JS_PATH ?>/custom.js"></script>
<!--dataTables -->
<script type="text/javascript" src="<?php echo base_url().ADMIN_JS_PATH ?>jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo base_url().ADMIN_JS_PATH ?>dataTables.bootstrap.js"></script>
<script>
                      $(document).ready(function () {
                              $('#dataTables-example').dataTable();
                              $('#dataTables-example2').dataTable();
                              $('#dataTables-example3').dataTable();
                                $('#dataTables-example4').dataTable();
                      });
      </script>

  <!--dataTables -->


<script>
function myFunction() {
  confirm("Press a button!");
}
</script>

<script>
  $(document).ready(function(){
  $("#delete").click(function(){
    if (!confirm("Do you want to delete this record")){
      return false;
    }
  });
});
</script>


</body>

</html>