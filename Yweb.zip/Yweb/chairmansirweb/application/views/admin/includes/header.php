<!DOCTYPE html>

<html>

<head>

  <meta charset="UTF-8">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Web</title>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url().ADMIN_CSS_PATH ?>bootstrap/bootstrap.css">

<link rel="stylesheet" href="<?php echo base_url().ADMIN_CSS_PATH ?>style.css">


<?php $segment= $this->uri->segment(2);

if($segment == ''){?>
<link rel="stylesheet" href="<?php echo base_url().ADMIN_CSS_PATH ?>login.css">
<?php }?>

</head>

<body>
   
<div id="throbber" style="display:none; min-height:120px;"></div>
<div id="noty-holder"></div>
<div id="wrapper">
    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="http://cijulenlinea.ucr.ac.cr/dev-users/">
            <img src="<?php echo base_url().ADMIN_IMAGES_PATH ?>/c_logo.png" alt="LOGO">
            </a>
        </div>
        <!-- Top Menu Items -->
        <ul class="nav navbar-right top-nav">
            <li><span class="lastlogintime">Last Login Time 26-10-2019 : 05:22</span>
            </li>            
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Admin User <b class="fa fa-angle-down"></b></a>
                <ul class="dropdown-menu">
                    <li><a href="#"><i class="fa fa-fw fa-user"></i> Edit Profile</a></li>
                    <li><a href="#"><i class="fa fa-fw fa-cog"></i> Change Password</a></li>
                    <li class="divider"></li>
                    <li><a href="<?php echo base_url('admin_login/logout'); ?>"><i class="fa fa-fw fa-power-off"></i> Logout</a></li>
                </ul>
            </li>
        </ul>
        <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
        <div class="collapse navbar-collapse navbar-ex1-collapse">
            <ul class="nav navbar-nav side-nav">
                <li>
                    <a href="#" data-toggle="collapse" data-target="#submenu-1"><i class="fa fa-fw fa-home"></i> HOME <i class="fa fa-fw fa-angle-down pull-right"></i></a>
                    <ul id="submenu-1" class="collapse">
                        <li><a href="<?php echo base_url('admin/list_sociallinks'); ?>"><i class="fa fa-angle-double-right"></i>Social Links</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i>test</a></li>
                       
                    </ul>
                </li>



             <li>
                    <a href="#" data-toggle="collapse" data-target="#submenu-2"><i class="fa fa-fw fa-star"></i>CMS<i class="fa fa-fw fa-angle-down pull-right"></i></a>
                    <ul id="submenu-2" class="collapse">
                        <li><a href="<?php echo base_url('admin/list_about'); ?>"><i class="fa fa-angle-double-right"></i> About</a></li>
                        <li><a href="<?php echo base_url('admin/list_profilefileds'); ?>"><i class="fa fa-angle-double-right"></i>Profile Fileds</a></li>
                    <li><a href="<?php echo base_url('admin/list_profiledetials'); ?>"><i class="fa fa-angle-double-right"></i>Profile Detials</a></li>
                    </ul>
                </li>

                     <li>
                    <a href="#" data-toggle="collapse" data-target="#submenu-3"><i class="fa fa-fw fa-star"></i>Achievements<i class="fa fa-fw fa-angle-down pull-right"></i></a>
                    <ul id="submenu-3" class="collapse">
                    <li><a href="<?php echo base_url('admin/list_achievements_content'); ?>"><i class="fa fa-angle-double-right"></i> Content</a></li>
                    <li><a href="<?php echo base_url('admin/add_achievementsgallery'); ?>"><i class="fa fa-angle-double-right"></i> Gallery</a></li>
                       
                    </ul>
                </li>
                
           <!--      <li>
                    <a href="<?php //echo base_url('admin/list_about'); ?>" data-toggle="collapse" data-target="#submenu-2"><i class="fa fa-fw fa-star"></i> ABOUT US <i class="fa fa-fw fa-angle-down pull-right"></i></a>
                    <ul id="submenu-2" class="collapse">
                        <li><a href="#"><i class="fa fa-angle-double-right"></i>About</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i> SUBMENU 2.2</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i> SUBMENU 2.3</a></li>
                    </ul>
                </li> -->

                <li>
                    <a href="<?php echo base_url('admin/list_vision'); ?>"><i class="fa fa-fw fa-user-plus"></i>  Vision</a>
                </li>
                <li>
                    <a href="sugerencias"><i class="fa fa-fw fa-paper-plane-o"></i> MENU 4</a>
                </li>
                <li>
                    <a href="faq"><i class="fa fa-fw fa fa-question-circle"></i> Permanently Delete List</a>
                </li>
            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </nav>




