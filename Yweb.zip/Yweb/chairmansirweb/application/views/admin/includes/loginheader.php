<!DOCTYPE html>

<html>

<head>

  <meta charset="UTF-8">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Web</title>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo base_url().ADMIN_CSS_PATH ?>bootstrap/bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url().ADMIN_CSS_PATH ?>login.css">

<!-- <?php $segment= $this->uri->segment(2);

if($segment == ''){?>
<link rel="stylesheet" href="<?php echo base_url().ADMIN_CSS_PATH ?>login.css">
<?php }
?> -->

</head>

<body>
   
<div id="throbber" style="display:none; min-height:120px;"></div>
<div id="noty-holder"></div>
<div id="wrapper">





