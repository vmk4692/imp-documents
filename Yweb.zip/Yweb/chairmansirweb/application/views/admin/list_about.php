
        <div id="page-wrapper">
        <div class="container-fluid">

  <?php echo $message; ?>

   <div class="f-left">
  <h4><u>About List</u></h4>
  </div>
   <div class="f-right">
  <a href="<?php echo base_url('admin/add_about'); ?>" class="btn btn-primary btnbottom">Create</a>
  </div>
  <div class="clears"></div>

<div class="table-responsive">
<table class="table table-striped table-bordered table-hover" id="dataTables-example">
<thead>

<tr>
<th>S.no</th>
<th>Title</th>
<!-- <th>Content</th> -->
<th>Image</th>
<th>Status</th>
<th>Action</th>
</tr>

</thead>
<tbody>
	<?php $i=1; ?>

 <?php foreach ($aboutdata as $data) {?>

 <tr>
 	<td><?php echo $i++; ?></td>
 	<td><?php echo $data['title']; ?></td>
 	<!-- <td><?php //echo substr($data['content'],0,100); ?>...</td> -->
 	<td>
  <a href="<?php echo base_url(); ?>/<?php echo $data['image']; ?>">
  <img src="<?php echo base_url(); ?>/<?php echo $data['image']; ?>" width="80" height="80">
  </a>
  </td>
 	<td>
 	<?php //echo $data['status']; 
    if($data['status']=='Active'){?>

    	<a href="<?php echo base_url(); ?>/admin/update_status/<?php echo $data['id']; ?>/<?php echo $data['status']; ?> " class="btn btn-success btn-xs"> Active</a>
      
    <?php }
    else if($data['status']=='Inactive'){?>
       <a href="<?php echo base_url(); ?>/admin/update_status/<?php echo $data['id']; ?>/<?php echo $data['status']; ?>"class="btn btn-danger btn-xs"> Inactive</a>
    <?php }

 	?>
 		
 	</td>
 	<td>
    <a href="<?php echo base_url(); ?>/admin/edit_about/<?php echo $data['id']; ?>"class="btn btn-primary btn-xs">Edit</a>
  <a href="<?php echo base_url(); ?>/admin/delete_status/<?php echo $data['id']; ?>/<?php echo $data['delete_status']; ?>"class="btn btn-danger btn-xs" id="delete" >Delete</a>
  </td>
</tr>


<?php }
?>


</tbody>
</table>
</div>
</div>
<!-- /#page-wrapper -->
