
        <div id="page-wrapper">
        <div class="container-fluid">


<?php echo $message; ?>
<div class="f-left">
  <h4><u>List Profile Fileds</u></h4>
  </div>
<div class="f-right">
  <a href="<?php echo base_url('admin/add_profilefileds'); ?>" class="btn btn-primary btnbottom">Create</a>
  </div> 
  <div class="clears"></div> 

<div class="table-responsive">
<table class="table table-striped table-bordered table-hover" id="dataTables-example">
<thead>
<?php $i=1; ?>

<tr>
<th>S.no</th>
<th>Filed Name</th>
<th>Status</th>
<th>Action</th>
</tr>

</thead>
<tbody>
  <?php $i=1; ?>
 <?php foreach ($profilefiledsdata as $data) {?>
  <tr>
<td><?php echo $i++; ?></td>
  <td><?php echo $data['filedname']; ?></td>
 

<td>
  <?php //echo $data['status']; 
    if($data['status']=='Active'){?>

      <a href="<?php echo base_url(); ?>/admin/profilefileds_status/<?php echo $data['id']; ?>/<?php echo $data['status']; ?> " class="btn btn-success btn-xs"> Active</a>
      
    <?php }
    else if($data['status']=='Deactive'){?>
       <a href="<?php echo base_url(); ?>/admin/profilefileds_status/<?php echo $data['id']; ?>/<?php echo $data['status']; ?>"class="btn btn-danger btn-xs"> Deactive</a>
    <?php }

  ?>
    
  </td>
  <td>
    <a href="<?php echo base_url(); ?>/admin/edit_profilefileds/<?php echo $data['id']; ?>"class="btn btn-primary btn-xs">Edit</a>
  <a href="<?php echo base_url(); ?>/admin/deletestau_profilefileds/<?php echo $data['id']; ?>/<?php echo $data['delete_status']; ?>"class="btn btn-danger btn-xs" id="delete" >Delete</a>
  </td>
</tr>


<?php }
?>


</tbody>
</table>
</div>
</div>
<!-- /#page-wrapper -->
