<!-- 

 -->
        <div id="page-wrapper">
        <div class="container-fluid">


<?php echo $message; ?>
<div class="f-left">
  <h4><u>Social Media Links</u></h4>
  </div>
<!-- <div class="f-right">
  <a href="<?php echo base_url('admin/list_sociallinks'); ?>" class="btn btn-primary btnbottom">Crate</a>
  </div> -->
  <div class="clears"></div> 

<div class="table-responsive">
<table class="table table-striped table-bordered table-hover" id="dataTables-example">
<thead>

<tr>
<th>S.no</th>
<th>Facebook Link</th>
<th>Twitter Link</th>
<th>Youtube Link</th>
<th>Instagram Link</th>
<th>Web Email</th>
<th>Action</th>
</tr>

</thead>
<tbody>
  <?php $i=0; ?>
<?php foreach ($sdata as $data) {?>
 <tr class="odd gradeX">
  <td><?php echo ++$i; ?></td>
  <td><a href="<?php echo $data['facebook_link']; ?>" target="_blank"><?php echo $data['facebook_link']; ?></a></td>
  <td><a href="<?php echo $data['twitter_link']; ?>" target="_blank"><?php echo $data['twitter_link']; ?></a></td>
  <td><a href="<?php echo $data['youtube_link']; ?>" target="_blank"><?php echo $data['youtube_link']; ?></a></td>
  <td><a href="<?php echo $data['instagram_link']; ?>" target="_blank"><?php echo $data['instagram_link']; ?></a></td>
  <td><a href="<?php echo $data['web_email']; ?>" target="_blank"><?php echo $data['web_email']; ?></a></td>
  <td><a href="<?php echo base_url('admin/edit_sociallinks'); ?>/<?php echo $data['id']; ?>" class="btn btn-primary btn-xs">Edit</a></td>
 </tr>
<?php }
?>




</tbody>
</table>
</div>
</div>
<!-- /#page-wrapper -->
