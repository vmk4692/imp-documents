    <div id="login">

        

        <div class="container">

            <div id="login-row" class="row justify-content-center align-items-center">

                <div id="login-column" class="col-md-12">

                	<div class="text-center">

                	<h3 class="text-center text-white pt-5">Admin Login</h3>

                </div>

                    <div id="login-box">

                        <form id="login-form" class="form" action="<?php echo base_url('Admin_login'); ?>" method="post">



                            <h3 class="text-center text-info">Login</h3>

                            <div class="form-group">

                                <label  class="text-info">Username:</label><br>

                                <input type="text" name="user"  class="form-control" required>

                            </div>

                            <div class="form-group">

                                <label  class="text-info">Password:</label><br>

                                <input type="text" name="password"  class="form-control" required>

                            </div>

                            <div class="form-group">

                                <label for="remember-me" class="text-info"><span>Remember me</span> <span><input  name="remember-me" type="checkbox"></span></label><br>

                                <input type="submit" name="submit" class="btn btn-info btn-md" value="submit">

                            </div>

                              <div id="register-link" class="text-right">

                                <a href="<?php echo base_url() ?>admin/forgot_password" class="text-info">Forgot Password?</a>

                            </div>

                         

                        </form>

                    </div>

                </div>

            </div>

        </div>

    </div>

   





