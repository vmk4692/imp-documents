    
          <style type="text/css">
       #login .text-white{padding: 13px 98px;}
       #login .container #login-row #login-column #login-box{
        height: 308px;
       }
   </style> 
    <div id="login">
        
        <div class="container">
            <div id="login-row" class="row justify-content-center align-items-center">
                <div id="login-column" class="col-md-12">
                    <div class="text-center">
                    <h3 class="text-center text-white pt-5">Update Password</h3>
                </div>
                    <div id="login-box">
                        <form id="login-form" class="form" action="<?php echo base_url() ?>admin/update_password" method="post" onSubmit = "return checkPassword(this)">
<?php if($this->session->flashdata('success') != ''){?>
                                    <div class="alert alert-block alert-success">
                                        <button type="button" class="close" data-dismiss="alert">
                                        <i class="fa fa-close"></i>
                                        </button>
                                        <p>
                                            <i class="icon-ok"></i>
                                            <?php echo $this->session->flashdata('success')?$this->session->flashdata('success'):'';?>
                                        </p>
                                    </div>
                             <?php } ?>
                               <?php if($this->session->flashdata('error') != ''){?>
                                    <div class="alert alert-block alert-danger">
                                        <button type="button" class="close" data-dismiss="alert">
                                        <i class="fa fa-close"></i>
                                        </button>
                                        <p>
                                            <i class="icon-ok"></i>
                                            <?php echo $this->session->flashdata('error')?$this->session->flashdata('error'):'';?>
                                        </p>
                                    </div>
                             <?php } ?>

                         <div class="form-group">
                                <label  class="text-info">New Password:</label><br>
                                <input type="text" name="password1"  class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label  class="text-info">Confirm Password:</label><br>
                                <input type="text" name="password2"  class="form-control" required>
                            </div>
                            <div class="form-group">
                              <br/>
                                <input type="submit" name="submit" class="btn btn-info btn-md" value="submit">
                            </div>
                                <div id="register-link" class="text-right">

                                <a href="<?php echo base_url() ?>admin/" class="text-info">Login Here?</a>

                            </div>
                            
                         
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
   


   <script> 
          
            // Function to check Whether both passwords 
            // is same or not. 
            function checkPassword(form) { 
                password1 = form.password1.value; 
                password2 = form.password2.value; 
  
                // If password not entered 
                if (password1 == '') 
                    alert ("Please enter Password"); 
                      
                // If confirm password not entered 
                else if (password2 == '') 
                    alert ("Please enter confirm password"); 
                      
                // If Not same return False.     
                else if (password1 != password2) { 
                    alert ("\nPassword did not match: Please try again...") 
                    return false; 
                } 
  
                // If same return True. 
               else{ 
                    //alert("Password Match: Welcome to GeeksforGeeks!") 
                    return true; 
                } 
            } 
        </script> 